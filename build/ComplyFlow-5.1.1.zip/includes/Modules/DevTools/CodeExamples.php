<?php
namespace ComplyFlow\Modules\DevTools;

if (!defined('ABSPATH')) {
    exit;
}

class CodeExamples {
    public static function get_examples() {
        return [
            'Register custom DSR data source' => "add_action('complyflow_dsr_collect', function( 24email,  24type) { /* ... */ }, 10, 2);",
            'Modify consent categories' => "add_filter('complyflow_consent_categories', function( 24cats) {  24cats['custom'] = 'Custom Tool'; return  24cats; });",
            'Get compliance score' => "do_action('complyflow_after_score',  24score);"
        ];
    }
}
