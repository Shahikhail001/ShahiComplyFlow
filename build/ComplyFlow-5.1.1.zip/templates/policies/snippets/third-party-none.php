<p>We do not use third-party services that collect or process your personal information beyond what is strictly necessary for the operation of our Site.</p>

<p>All data processing is performed directly by us or through trusted service providers who are contractually obligated to protect your data and use it only for the specific services they provide to us.</p>
