<h3>Children's Privacy</h3>
<p>Our website is not intended for children under the age of 13 (or 16 in the European Economic Area). We do not knowingly collect personal information from children under these ages.</p>

<p>If we become aware that we have collected personal information from a child under the applicable age without parental consent, we will take steps to delete that information as quickly as possible.</p>

<p>If you believe we have collected information from a child, please contact us immediately.</p>
