<h3>Social Media Integration</h3>
<p>Our website includes social media features and widgets (such as Facebook Like button, Twitter share button). These features may collect your IP address, which page you are visiting, and may set a cookie.</p>
<p>Your interactions with these features are governed by the privacy policies of the respective social media companies.</p>
