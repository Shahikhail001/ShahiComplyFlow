<h3>Marketing Data Collection</h3>
<p>If you opt-in to our marketing communications, we collect:</p>
<ul>
    <li><strong>Email Marketing:</strong> Email address, name, preferences</li>
    <li><strong>Advertising Data:</strong> Information about ads you view and interact with</li>
    <li><strong>Interest Data:</strong> Your interests based on your browsing behavior</li>
</ul>
<p>You can opt-out of marketing communications at any time by clicking the unsubscribe link in our emails or contacting us directly.</p>
