(function ($) {
    'use strict';

    const $noticeArea = $('#cf-template-wizard-notice');

    function showNotice(type, message) {
        if (!$noticeArea.length) {
            return;
        }

        $noticeArea.html(
            '<div class="notice notice-' + type + ' inline"><p>' + message + '</p></div>'
        );
    }

    function copyShortcode($button) {
        const shortcode = $button.data('shortcode');
        if (!shortcode) {
            return;
        }

        navigator.clipboard.writeText(shortcode)
            .then(() => {
                showNotice('success', cfTemplateWizard.strings.copied);
                $button.addClass('cf-button-success');
                setTimeout(() => $button.removeClass('cf-button-success'), 1500);
            })
            .catch(() => {
                showNotice('error', cfTemplateWizard.strings.error);
            });
    }

    function importSamples($button) {
        $button.prop('disabled', true).text(cfTemplateWizard.strings.importing);
        showNotice('info', cfTemplateWizard.strings.importing);

        $.post(cfTemplateWizard.ajaxUrl, {
            action: 'cf_seed_html_templates',
            nonce: cfTemplateWizard.nonce,
        })
            .done((response) => {
                if (response && response.success) {
                    showNotice('success', cfTemplateWizard.strings.imported);
                    setTimeout(() => {
                        window.location.reload();
                    }, 800);
                    return;
                }

                const message = response && response.data && response.data.message
                    ? response.data.message
                    : cfTemplateWizard.strings.error;
                showNotice('error', message);
            })
            .fail(() => {
                showNotice('error', cfTemplateWizard.strings.error);
            })
            .always(() => {
                $button.prop('disabled', false).text(cfTemplateWizard.strings.button);
            });
    }

    $(document).on('click', '.cf-template-copy', function (event) {
        event.preventDefault();
        copyShortcode($(this));
    });

    $('#cf-import-templates').on('click', function (event) {
        event.preventDefault();
        importSamples($(this));
    });
})(jQuery);
