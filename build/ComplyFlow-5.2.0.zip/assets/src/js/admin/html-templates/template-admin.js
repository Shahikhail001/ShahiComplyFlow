/**
 * HTML Template Admin Interface
 * 
 * Handles file upload, image detection, and Media Library integration.
 * 
 * @package ComplyFlow
 * @since 5.2.0
 */

(function($) {
    'use strict';

    const CFTemplates = {
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.initMediaLibrary();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // File upload
            $(document).on('change', '#cf_html_file', this.handleFileSelect.bind(this));
            $(document).on('click', '#cf_upload_template', this.uploadTemplate.bind(this));

            // Image detection
            $(document).on('click', '#cf_detect_images', this.detectImages.bind(this));

            // Save mappings
            $(document).on('click', '#cf_save_mappings', this.saveMappings.bind(this));

            // Preview
            $(document).on('click', '#cf_preview_template', this.previewTemplate.bind(this));

            // Copy shortcode
            $(document).on('click', '#cf_copy_shortcode', this.copyShortcode.bind(this));
        },

        /**
         * Handle file selection
         */
        handleFileSelect: function(e) {
            const file = e.target.files[0];
            if (!file) return;

            // Validate file type
            if (!file.name.match(/\.(html|htm)$/i)) {
                this.showError(window.cfTemplates.fileTypeError);
                $(e.target).val('');
                return;
            }

            // Validate file size (5MB)
            if (file.size > 5242880) {
                this.showError(window.cfTemplates.fileSizeError);
                $(e.target).val('');
                return;
            }

            // Show file info
            $('.cf-file-info').html(
                '<strong>' + window.cfTemplates.selectedFile + ':</strong> ' + 
                file.name + ' (' + this.formatFileSize(file.size) + ')'
            ).show();

            // Enable upload button
            $('#cf_upload_template').prop('disabled', false);
        },

        /**
         * Upload template via AJAX
         */
        uploadTemplate: function(e) {
            e.preventDefault();

            const $button = $(e.currentTarget);
            const fileInput = document.getElementById('cf_html_file');
            
            if (!fileInput.files.length) {
                this.showError(window.cfTemplates.noFileSelected);
                return;
            }

            const formData = new FormData();
            formData.append('action', 'cf_upload_html_template');
            formData.append('nonce', window.cfTemplates.nonce);
            formData.append('post_id', window.cfTemplates.postId);
            formData.append('html_file', fileInput.files[0]);

            // Show progress
            $button.prop('disabled', true).text(window.cfTemplates.uploading);
            this.hideMessages();

            $.ajax({
                url: window.ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: (response) => {
                    if (response.success) {
                        this.showSuccess(window.cfTemplates.uploadSuccess);
                        
                        // Reload page to show updated content
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        this.showError(response.data.message || window.cfTemplates.uploadError);
                        $button.prop('disabled', false).text(window.cfTemplates.uploadButton);
                    }
                },
                error: () => {
                    this.showError(window.cfTemplates.uploadError);
                    $button.prop('disabled', false).text(window.cfTemplates.uploadButton);
                }
            });
        },

        /**
         * Detect images in template
         */
        detectImages: function(e) {
            e.preventDefault();

            const $button = $(e.currentTarget);
            $button.prop('disabled', true).text(window.cfTemplates.detecting);

            $.ajax({
                url: window.ajaxurl,
                type: 'POST',
                data: {
                    action: 'cf_detect_template_images',
                    nonce: window.cfTemplates.nonce,
                    post_id: window.cfTemplates.postId
                },
                success: (response) => {
                    if (response.success) {
                        this.showSuccess(window.cfTemplates.detectSuccess);
                        
                        // Reload to show detected images
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        this.showError(response.data.message || window.cfTemplates.detectError);
                        $button.prop('disabled', false).text(window.cfTemplates.detectButton);
                    }
                },
                error: () => {
                    this.showError(window.cfTemplates.detectError);
                    $button.prop('disabled', false).text(window.cfTemplates.detectButton);
                }
            });
        },

        /**
         * Save image mappings
         */
        saveMappings: function(e) {
            e.preventDefault();

            const mappings = [];
            $('.cf-image-row').each(function() {
                const $row = $(this);
                mappings.push({
                    id: $row.data('id'),
                    url: $row.find('.cf-image-url').val(),
                    selector: $row.data('selector'),
                    type: $row.data('type')
                });
            });

            const $button = $(e.currentTarget);
            $button.prop('disabled', true).text(window.cfTemplates.saving);

            $.ajax({
                url: window.ajaxurl,
                type: 'POST',
                data: {
                    action: 'cf_save_image_mappings',
                    nonce: window.cfTemplates.nonce,
                    post_id: window.cfTemplates.postId,
                    mappings: JSON.stringify(mappings)
                },
                success: (response) => {
                    if (response.success) {
                        this.showSuccess(window.cfTemplates.saveSuccess);
                        $button.prop('disabled', false).text(window.cfTemplates.saveButton);
                    } else {
                        this.showError(response.data.message || window.cfTemplates.saveError);
                        $button.prop('disabled', false).text(window.cfTemplates.saveButton);
                    }
                },
                error: () => {
                    this.showError(window.cfTemplates.saveError);
                    $button.prop('disabled', false).text(window.cfTemplates.saveButton);
                }
            });
        },

        /**
         * Preview template in modal
         */
        previewTemplate: function(e) {
            e.preventDefault();

            const $button = $(e.currentTarget);
            $button.prop('disabled', true);

            $.ajax({
                url: window.ajaxurl,
                type: 'POST',
                data: {
                    action: 'cf_preview_template',
                    nonce: window.cfTemplates.nonce,
                    post_id: window.cfTemplates.postId
                },
                success: (response) => {
                    if (response.success) {
                        this.showPreviewModal(response.data.html);
                    } else {
                        this.showError(response.data.message || window.cfTemplates.previewError);
                    }
                    $button.prop('disabled', false);
                },
                error: () => {
                    this.showError(window.cfTemplates.previewError);
                    $button.prop('disabled', false);
                }
            });
        },

        /**
         * Show preview modal
         */
        showPreviewModal: function(html) {
            // Create modal if doesn't exist
            if (!$('#cf-preview-modal').length) {
                $('body').append(
                    '<div id="cf-preview-modal" class="cf-modal">' +
                        '<div class="cf-modal-content">' +
                            '<span class="cf-modal-close">&times;</span>' +
                            '<div class="cf-modal-body"></div>' +
                        '</div>' +
                    '</div>'
                );

                // Close modal on click
                $(document).on('click', '.cf-modal-close, #cf-preview-modal', function(e) {
                    if (e.target === this) {
                        $('#cf-preview-modal').hide();
                    }
                });
            }

            // Show modal with content
            $('#cf-preview-modal .cf-modal-body').html(html);
            $('#cf-preview-modal').show();
        },

        /**
         * Copy shortcode to clipboard
         */
        copyShortcode: function(e) {
            e.preventDefault();

            const $button = $(e.currentTarget);
            const shortcode = $button.data('shortcode');

            // Create temporary input
            const $temp = $('<input>');
            $('body').append($temp);
            $temp.val(shortcode).select();
            document.execCommand('copy');
            $temp.remove();

            // Show feedback
            const originalText = $button.text();
            $button.text(window.cfTemplates.copied);
            setTimeout(() => {
                $button.text(originalText);
            }, 2000);
        },

        /**
         * Initialize WordPress Media Library
         */
        initMediaLibrary: function() {
            $(document).on('click', '.cf-media-button', function(e) {
                e.preventDefault();

                const $button = $(this);
                const $input = $button.siblings('.cf-image-url');

                // Create media frame
                const frame = wp.media({
                    title: window.cfTemplates.selectImage,
                    button: {
                        text: window.cfTemplates.useImage
                    },
                    multiple: false
                });

                // On select
                frame.on('select', function() {
                    const attachment = frame.state().get('selection').first().toJSON();
                    $input.val(attachment.url);
                });

                frame.open();
            });
        },

        /**
         * Format file size
         */
        formatFileSize: function(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        },

        /**
         * Show success message
         */
        showSuccess: function(message) {
            this.hideMessages();
            $('.cf-messages').html(
                '<div class="notice notice-success"><p>' + message + '</p></div>'
            ).show();
        },

        /**
         * Show error message
         */
        showError: function(message) {
            this.hideMessages();
            $('.cf-messages').html(
                '<div class="notice notice-error"><p>' + message + '</p></div>'
            ).show();
        },

        /**
         * Hide all messages
         */
        hideMessages: function() {
            $('.cf-messages').hide().empty();
        }
    };

    // Initialize when ready
    $(document).ready(function() {
        if (window.cfTemplates) {
            CFTemplates.init();
        }
    });

})(jQuery);
