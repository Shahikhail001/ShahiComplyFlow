# HTML Template System - Complete Implementation Guide

## Overview

The HTML Template System is a comprehensive solution for importing, managing, and displaying HTML templates with dynamic image replacement capabilities. It integrates seamlessly with the ComplyFlow plugin architecture.

**Version:** 1.0.0  
**Implemented:** v5.2.0  
**Module ID:** `html_templates`

---

## Features

### Core Functionality

1. **HTML Template Import**
   - Upload HTML files (up to 5MB)
   - URL-based import
   - Validation and sanitization
   - Security checks (PHP tags, dangerous scripts)

2. **Image Detection**
   - Automatic detection using 4 methods:
     - `<img>` tags (src, empty src, data:image)
     - Background images (inline styles)
     - Data attributes (data-src, data-image, data-bg, data-background)
     - `<picture>` and `<source>` elements
   - Pattern matching for placeholder services:
     - placeholder.com, via.placeholder.com
     - placehold.it, placeholdit.net
     - lorempixel.com
     - unsplash.it
     - picsum.photos
     - example.com/image
     - data:image base64

3. **WordPress Media Library Integration**
   - Media picker for each detected image
   - URL input support
   - Visual image mapping interface

4. **Template Rendering**
   - Dynamic image replacement
   - Shortcode support: `[cf_template id="123"]`
   - Frontend display with customization
   - Preview functionality

5. **Export & Management**
   - Export templates with replaced images
   - Template statistics (completion %, unmapped images)
   - Custom Post Type architecture

---

## Architecture

### File Structure

```
includes/Modules/HTMLTemplates/
├── HTMLTemplateModule.php      # Main module controller
├── TemplatePostType.php        # Custom post type & meta boxes
├── ImageDetector.php           # Image detection engine
├── ImageReplacer.php           # Image replacement engine
├── TemplateImporter.php        # File upload handler
├── TemplateRenderer.php        # Frontend rendering
└── ShortcodeHandler.php        # Shortcode processing

assets/src/js/admin/html-templates/
└── template-admin.js           # Admin UI JavaScript

assets/src/css/admin/html-templates/
└── template-admin.css          # Admin styles

assets/src/css/frontend/html-templates/
└── template-frontend.css       # Frontend styles
```

### Class Responsibilities

#### HTMLTemplateModule
- **Purpose:** Central orchestrator
- **Responsibilities:**
  - Initialize post type, shortcode handler
  - Register AJAX handlers
  - Enqueue admin/frontend assets
  - Coordinate between components

#### TemplatePostType
- **Purpose:** Custom post type management
- **Responsibilities:**
  - Register `cf_html_template` post type
  - Render 4 meta boxes:
    - Upload: File upload interface
    - Images: Image mapping table
    - Preview: Preview/export actions
    - Shortcode: Copy-to-clipboard shortcode

#### ImageDetector
- **Purpose:** Find image placeholders in HTML
- **Methods:**
  - `detect($html)` - Main detection method
  - `detect_img_tags()` - Find `<img>` elements
  - `detect_background_images()` - Find inline background-image
  - `detect_data_attributes()` - Find data-* attributes
  - `detect_picture_elements()` - Find `<picture>/<source>`
  - `is_placeholder_url()` - Pattern matching
  - `generate_selector()` - CSS selector generation

#### ImageReplacer
- **Purpose:** Replace detected images with actual URLs
- **Methods:**
  - `replace($html, $mappings)` - Main replacement
  - `replace_img_tag()` - Replace IMG src
  - `replace_background_image()` - Replace inline backgrounds
  - `replace_data_attribute()` - Replace data attributes
  - `replace_source_srcset()` - Replace source srcset
  - `css_to_xpath()` - CSS to XPath conversion

#### TemplateImporter
- **Purpose:** Handle file uploads
- **Validation:**
  - File type (HTML only)
  - File size (5MB max)
  - MIME type checking
  - Security validation (PHP tags, dangerous scripts)
  - Content validation (minimum HTML structure)

#### TemplateRenderer
- **Purpose:** Render templates for display
- **Methods:**
  - `render($post_id, $args)` - Render template
  - `preview($post_id)` - Admin preview
  - `export($post_id)` - Export with replacements
  - `get_stats($post_id)` - Template statistics
  - `validate($post_id)` - Pre-render validation

#### ShortcodeHandler
- **Purpose:** Process `[cf_template]` shortcode
- **Attributes:**
  - `id` - Template post ID (required)
  - `wrap` - Wrap in container (default: true)
  - `container_class` - Custom container class

---

## Database Schema

### Post Type
- **Name:** `cf_html_template`
- **Supports:** title, editor (disabled)
- **Public:** false
- **Show in menu:** complyflow
- **Hierarchical:** false

### Post Meta Fields

| Meta Key | Type | Description |
|----------|------|-------------|
| `_cf_html_content` | string | Original HTML content |
| `_cf_html_file_name` | string | Original filename |
| `_cf_image_mappings` | array | Image detection and mapping data |

### Image Mapping Structure

```php
[
    [
        'id' => 0,                              // Unique ID
        'selector' => '#header-logo',            // CSS selector
        'type' => 'img_tag',                     // Detection type
        'current_value' => 'placeholder.com/...',// Original URL
        'url' => 'https://site.com/image.jpg',  // Replacement URL
        'alt' => 'Logo',                         // Alt text
        'class' => 'logo-img',                   // CSS classes
        'element_id' => 'header-logo',           // Element ID
        'attribute' => 'src'                     // Attribute name (for data types)
    ],
    // ... more mappings
]
```

---

## AJAX Endpoints

### 1. Upload Template
**Action:** `cf_upload_html_template`  
**Method:** POST  
**Nonce:** `cf_html_template_nonce`  
**Capability:** `edit_posts`

**Parameters:**
- `post_id` - Template post ID
- `html_file` - File upload ($_FILES)

**Response:**
```json
{
    "success": true,
    "data": {
        "message": "Template uploaded successfully",
        "filename": "landing-page.html",
        "size": 12345
    }
}
```

### 2. Detect Images
**Action:** `cf_detect_template_images`  
**Method:** POST  
**Nonce:** `cf_html_template_nonce`  
**Capability:** `edit_posts`

**Parameters:**
- `post_id` - Template post ID

**Response:**
```json
{
    "success": true,
    "data": {
        "detected": 15,
        "images": [ /* array of detected images */ ]
    }
}
```

### 3. Save Image Mappings
**Action:** `cf_save_image_mappings`  
**Method:** POST  
**Nonce:** `cf_html_template_nonce`  
**Capability:** `edit_posts`

**Parameters:**
- `post_id` - Template post ID
- `mappings` - JSON encoded array of mappings

**Response:**
```json
{
    "success": true,
    "data": {
        "message": "Image mappings saved successfully",
        "count": 15
    }
}
```

### 4. Preview Template
**Action:** `cf_preview_template`  
**Method:** POST  
**Nonce:** `cf_html_template_nonce`  
**Capability:** `edit_posts`

**Parameters:**
- `post_id` - Template post ID

**Response:**
```json
{
    "success": true,
    "data": {
        "html": "<div>...</div>"
    }
}
```

### 5. Export Template
**Action:** `cf_export_template`  
**Method:** POST  
**Nonce:** `cf_html_template_nonce`  
**Capability:** `edit_posts`

**Parameters:**
- `post_id` - Template post ID

**Response:**
```json
{
    "success": true,
    "data": {
        "html": "<!DOCTYPE html>...",
        "filename": "template-exported-2024-01-15-143022.html"
    }
}
```

---

## User Workflows

### Workflow 1: Import New Template

1. **Create Template**
   - Navigate to: `ComplyFlow > HTML Templates > Add New`
   - Enter template name/title

2. **Upload HTML File**
   - Click "Choose File" in Upload meta box
   - Select HTML file (max 5MB)
   - Click "Upload Template"
   - Wait for success message

3. **Detect Images**
   - Click "Detect Images" button
   - System scans HTML for image placeholders
   - Images displayed in Images meta box

4. **Map Images**
   - For each detected image:
     - Click "Select Image" to use Media Library
     - OR paste direct URL
   - Click "Save Image Mappings"

5. **Preview & Verify**
   - Click "Preview Template" to see result
   - Verify all images loaded correctly

6. **Use Template**
   - Copy shortcode from Shortcode meta box
   - Paste in any post/page: `[cf_template id="123"]`

### Workflow 2: Export Template

1. Navigate to template edit screen
2. Ensure all images are mapped
3. Click "Export Template"
4. Download HTML file with replaced images

---

## Shortcode Usage

### Basic Usage
```
[cf_template id="123"]
```

### With Custom Container
```
[cf_template id="123" container_class="my-custom-class"]
```

### Without Wrapper
```
[cf_template id="123" wrap="false"]
```

### In PHP
```php
echo do_shortcode('[cf_template id="123"]');
```

### Template Functions
```php
// Direct rendering
$renderer = new \ComplyFlow\Modules\HTMLTemplates\TemplateRenderer();
echo $renderer->render(123);

// With arguments
echo $renderer->render(123, [
    'wrap' => true,
    'container_class' => 'custom-template'
]);
```

---

## Security Measures

### 1. File Upload Security
- **MIME type validation:** text/html only
- **File extension check:** .html, .htm only
- **File size limit:** 5MB maximum
- **is_uploaded_file() check:** Prevent file injection
- **Dangerous content detection:**
  - PHP tags removed
  - eval() patterns blocked
  - document.write() patterns blocked
  - JavaScript event handlers sanitized
  - iframe javascript: protocols blocked

### 2. AJAX Security
- **Nonce verification:** All AJAX requests verified
- **Capability checks:** edit_posts or manage_options required
- **Input sanitization:**
  - URLs: `esc_url_raw()`
  - Text: `sanitize_text_field()`
  - HTML: DOMDocument parsing

### 3. Output Security
- **Escaping:** All output escaped appropriately
- **Shortcode validation:** Post type and status checked
- **Permission checks:** Unpublished templates require edit capability

---

## Hooks & Filters

### Actions

#### complyflow_html_template_uploaded
Fires after successful template upload.

```php
do_action('complyflow_html_template_uploaded', $post_id, $html, $filename);
```

#### complyflow_html_template_images_detected
Fires after images are detected.

```php
do_action('complyflow_html_template_images_detected', $post_id, $images);
```

### Filters

#### complyflow_html_template_render
Filters rendered template HTML.

```php
$html = apply_filters('complyflow_html_template_render', $html, $post_id, $args);
```

**Usage:**
```php
add_filter('complyflow_html_template_render', function($html, $post_id, $args) {
    // Modify rendered HTML
    return $html;
}, 10, 3);
```

#### complyflow_html_template_max_file_size
Filters maximum upload file size.

```php
$max_size = apply_filters('complyflow_html_template_max_file_size', 5242880); // 5MB
```

---

## JavaScript API

### Global Object: `window.cfTemplates`

Localized data available in admin:

```javascript
{
    nonce: 'abc123',
    postId: 456,
    ajaxUrl: '/wp-admin/admin-ajax.php',
    strings: {
        uploadSuccess: 'Template uploaded successfully',
        uploadError: 'Upload failed',
        // ... more strings
    }
}
```

### Events

#### File Upload
```javascript
$(document).on('change', '#cf_html_file', function(e) {
    // Handle file selection
});
```

#### Save Mappings
```javascript
$(document).on('click', '#cf_save_mappings', function(e) {
    // Collect and save image mappings
});
```

---

## CSS Classes

### Admin Styles

| Class | Purpose |
|-------|---------|
| `.cf-meta-box` | Meta box container |
| `.cf-upload-section` | Upload interface |
| `.cf-images-table` | Image mapping table |
| `.cf-image-row` | Individual image row |
| `.cf-image-type` | Type badge |
| `.cf-preview-section` | Preview controls |
| `.cf-stats` | Statistics grid |
| `.cf-modal` | Preview modal |

### Frontend Styles

| Class | Purpose |
|-------|---------|
| `.cf-html-template` | Template container |
| `.cf-template-wrapper` | Shortcode wrapper |

---

## Error Handling

### Upload Errors

| Error Code | Message | Solution |
|------------|---------|----------|
| `UPLOAD_ERR_INI_SIZE` | File too large | Reduce file size or increase PHP upload_max_filesize |
| `UPLOAD_ERR_FORM_SIZE` | Form size exceeded | Adjust POST_MAX_SIZE in PHP |
| `UPLOAD_ERR_NO_FILE` | No file uploaded | Select a file before uploading |
| Invalid MIME | Not an HTML file | Ensure file is .html or .htm |
| Dangerous content | Security risk detected | Remove PHP tags or dangerous scripts |

### Rendering Errors

| Error | Cause | Solution |
|-------|-------|----------|
| Template not found | Invalid post ID | Check template exists and is published |
| Permission denied | User lacks capability | Publish template or grant edit rights |
| Empty content | No HTML uploaded | Upload HTML file first |

---

## Performance Considerations

### Optimization Strategies

1. **Caching**
   - Rendered templates can be cached
   - Implement using WordPress transients

2. **Image Detection**
   - Only run when HTML content changes
   - Store results in post meta

3. **Asset Loading**
   - Admin assets only load on template pages
   - Frontend CSS minimal (< 1KB)

### Resource Usage

- **Memory:** ~2-5MB per template (depending on HTML size)
- **Database:** ~1-10KB per template (meta data)
- **File Storage:** HTML files stored in post meta (not files)

---

## Testing Checklist

### Functional Testing

- [ ] Upload HTML file successfully
- [ ] Detect IMG tags with placeholder URLs
- [ ] Detect background-image in inline styles
- [ ] Detect data-src attributes
- [ ] Detect picture/source elements
- [ ] Map images via Media Library
- [ ] Map images via direct URL
- [ ] Save image mappings
- [ ] Preview template with replaced images
- [ ] Export template to HTML file
- [ ] Display via shortcode
- [ ] Verify security checks (PHP tags blocked)

### Browser Compatibility

- [ ] Chrome/Edge (Chromium)
- [ ] Firefox
- [ ] Safari
- [ ] Mobile browsers

### WordPress Compatibility

- [ ] WordPress 6.4+
- [ ] PHP 8.0+
- [ ] Block editor integration
- [ ] Classic editor integration

---

## Troubleshooting

### Common Issues

#### Issue: "Template not found" error
**Solution:** Ensure template post status is "publish" or you have edit permissions.

#### Issue: Images not detected
**Solution:** Check if images use supported placeholder patterns. Add custom patterns via filter if needed.

#### Issue: Preview shows broken images
**Solution:** Verify image URLs are accessible and properly mapped.

#### Issue: Shortcode displays nothing
**Solution:** Check template ID is correct and content is not empty.

#### Issue: Upload fails
**Solution:** 
1. Check file size < 5MB
2. Verify file is HTML
3. Increase PHP upload_max_filesize if needed
4. Check server error logs

---

## Template Wizard & Sample Library

### Location
- WordPress Admin → **ComplyFlow → Template Wizard**

### Overview
- Provides a card-based gallery of every `cf_html_template` post with quick actions
- Displays template statistics (total, sample, custom) for rapid audits
- Offers shortcode copy, edit links, and direct HTML download buttons per template
- Contains onboarding notices explaining sanitization and usage tips

### Sample Templates
- Bundled templates: **Acme SaaS Launch** and **Stellar App Ignite**
- Automatically seeded on activation or first admin load (never an empty wizard)
- Can be reinstalled via the “Import Sample Templates” button (AJAX `cf_seed_html_templates`)
- Sample posts are flagged with meta `_cf_template_origin = sample` for easy cleanup

### Assets
- Styles: `assets/src/css/admin/html-templates/template-wizard.css`
- Script: `assets/src/js/admin/html-templates/template-wizard.js`
- Localized strings + nonce namespace: `cf_template_wizard`

### Permissions & Security
- Page + AJAX endpoint require `manage_options`
- AJAX uses nonce `cf_template_wizard` and returns JSON responses with status messages

---

## Future Enhancements

### Planned Features (v1.1.0)

1. **Bulk Import**
   - Import multiple templates from ZIP
   - CSV mapping for batch image replacement

2. **Template Library**
   - Pre-built template collection
   - One-click template installation

3. **Version Control**
   - Track template changes
   - Rollback to previous versions

4. **Advanced Replacement**
   - Text replacement (not just images)
   - CSS variable injection
   - JavaScript configuration

5. **Template Categories**
   - Organize templates by type
   - Custom taxonomies support

6. **REST API**
   - Full CRUD operations
   - Webhook support for external integrations

---

## Code Examples

### Custom Image Detection Pattern

```php
add_filter('complyflow_html_template_placeholder_patterns', function($patterns) {
    $patterns[] = 'mycustomcdn.com/placeholder';
    return $patterns;
});
```

### Modify Template Before Rendering

```php
add_filter('complyflow_html_template_render', function($html, $post_id, $args) {
    // Add custom wrapper
    $html = '<div class="my-wrapper">' . $html . '</div>';
    
    // Inject custom script
    $html .= '<script>console.log("Template loaded");</script>';
    
    return $html;
}, 10, 3);
```

### Programmatic Template Creation

```php
// Create template post
$post_id = wp_insert_post([
    'post_title' => 'My Template',
    'post_type' => 'cf_html_template',
    'post_status' => 'publish'
]);

// Store HTML content
update_post_meta($post_id, '_cf_html_content', $html_content);

// Detect images
$detector = new \ComplyFlow\Modules\HTMLTemplates\ImageDetector();
$images = $detector->detect($html_content);

// Save mappings
update_post_meta($post_id, '_cf_image_mappings', $images);
```

---

## Support & Contributing

### Getting Help
- Documentation: This file
- GitHub Issues: Report bugs
- Support Forum: Community assistance

### Contributing
1. Follow WordPress Coding Standards
2. Use PHP 8.0+ type hints
3. Add PHPDoc comments
4. Test all functionality
5. Submit pull request

---

## Changelog

### Version 1.0.0 (2024-01-15)
- Initial release
- HTML file upload support
- 4 image detection methods
- WordPress Media Library integration
- Custom post type architecture
- Shortcode rendering
- Export functionality
- Security validation
- Admin UI with AJAX
- Comprehensive documentation

---

## License

This module is part of the ComplyFlow plugin and follows the same GPL v2 or later license.

---

## Credits

**Developed by:** ShahiSoft Team  
**For:** ComplyFlow v5.2.0  
**Architecture:** Option 2 - Advanced Template Builder with Custom Post Type

**Technologies Used:**
- PHP 8.0+ (DOMDocument, DOMXPath)
- WordPress Custom Post Types
- WordPress Media Library
- jQuery & AJAX
- CSS Grid & Flexbox
