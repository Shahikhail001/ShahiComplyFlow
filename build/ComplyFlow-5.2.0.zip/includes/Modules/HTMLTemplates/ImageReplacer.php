<?php
/**
 * Image Replacer
 *
 * Replaces image placeholders in HTML with actual image URLs.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Image Replacer Class
 *
 * @since 5.2.0
 */
class ImageReplacer {
    /**
     * Replace images in HTML content
     *
     * @param string $html     HTML content.
     * @param array  $mappings Image mappings.
     * @return string Modified HTML.
     */
    public function replace(string $html, array $mappings): string {
        if (empty($html) || empty($mappings)) {
            return $html;
        }

        $dom = new \DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIES | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        
        $xpath = new \DOMXPath($dom);

        foreach ($mappings as $mapping) {
            if (empty($mapping['url'])) {
                continue;
            }

            $type = $mapping['type'] ?? 'img_tag';
            $selector = $mapping['selector'] ?? '';
            $url = esc_url($mapping['url']);

            switch ($type) {
                case 'img_tag':
                    $this->replace_img_tag($xpath, $selector, $url, $mapping);
                    break;

                case 'background_image':
                    $this->replace_background_image($xpath, $selector, $url);
                    break;

                case 'data_attribute':
                    $this->replace_data_attribute($xpath, $selector, $url, $mapping);
                    break;

                case 'source_srcset':
                    $this->replace_source_srcset($xpath, $selector, $url);
                    break;
            }
        }

        return $dom->saveHTML();
    }

    /**
     * Replace IMG tag src attribute
     *
     * @param \DOMXPath $xpath    XPath instance.
     * @param string    $selector CSS selector.
     * @param string    $url      New image URL.
     * @param array     $mapping  Full mapping data.
     * @return void
     */
    private function replace_img_tag(\DOMXPath $xpath, string $selector, string $url, array $mapping): void {
        $nodes = $this->query_by_selector($xpath, $selector, 'img');

        foreach ($nodes as $node) {
            $node->setAttribute('src', $url);
            
            // Update alt text if provided
            if (!empty($mapping['alt'])) {
                $node->setAttribute('alt', sanitize_text_field($mapping['alt']));
            }
        }
    }

    /**
     * Replace background image in inline style
     *
     * @param \DOMXPath $xpath    XPath instance.
     * @param string    $selector CSS selector.
     * @param string    $url      New image URL.
     * @return void
     */
    private function replace_background_image(\DOMXPath $xpath, string $selector, string $url): void {
        $nodes = $this->query_by_selector($xpath, $selector);

        foreach ($nodes as $node) {
            $style = $node->getAttribute('style');
            
            // Replace background-image URL
            $new_style = preg_replace(
                '/background(?:-image)?\s*:\s*url\(["\']?[^"\')]+["\']?\)/i',
                'background-image: url(' . $url . ')',
                $style
            );
            
            // If no background-image found, add it
            if ($new_style === $style && !preg_match('/background(?:-image)?/i', $style)) {
                $new_style = trim($style, '; ') . '; background-image: url(' . $url . ')';
            }
            
            $node->setAttribute('style', $new_style);
        }
    }

    /**
     * Replace data attribute value
     *
     * @param \DOMXPath $xpath    XPath instance.
     * @param string    $selector CSS selector.
     * @param string    $url      New image URL.
     * @param array     $mapping  Full mapping data.
     * @return void
     */
    private function replace_data_attribute(\DOMXPath $xpath, string $selector, string $url, array $mapping): void {
        $attribute = $mapping['attribute'] ?? 'data-src';
        $nodes = $this->query_by_selector($xpath, $selector);

        foreach ($nodes as $node) {
            $node->setAttribute($attribute, $url);
        }
    }

    /**
     * Replace source srcset attribute
     *
     * @param \DOMXPath $xpath    XPath instance.
     * @param string    $selector CSS selector.
     * @param string    $url      New image URL.
     * @return void
     */
    private function replace_source_srcset(\DOMXPath $xpath, string $selector, string $url): void {
        $nodes = $this->query_by_selector($xpath, $selector, 'source');

        foreach ($nodes as $node) {
            $node->setAttribute('srcset', $url);
        }
    }

    /**
     * Query DOM by CSS selector
     *
     * @param \DOMXPath $xpath       XPath instance.
     * @param string    $selector    CSS selector.
     * @param string    $tag_filter  Optional tag name filter.
     * @return \DOMNodeList|false
     */
    private function query_by_selector(\DOMXPath $xpath, string $selector, string $tag_filter = '') {
        // Convert CSS selector to XPath
        $xpath_query = $this->css_to_xpath($selector, $tag_filter);
        return @$xpath->query($xpath_query);
    }

    /**
     * Convert CSS selector to XPath
     *
     * @param string $selector   CSS selector.
     * @param string $tag_filter Optional tag filter.
     * @return string XPath query.
     */
    private function css_to_xpath(string $selector, string $tag_filter = ''): string {
        // Handle ID selector
        if (preg_match('/^#([\w-]+)$/', $selector, $matches)) {
            $xpath = '//*[@id="' . $matches[1] . '"]';
            if ($tag_filter) {
                $xpath = '//' . $tag_filter . '[@id="' . $matches[1] . '"]';
            }
            return $xpath;
        }

        // Handle class selector
        if (preg_match('/^\.([\w.-]+)$/', $selector, $matches)) {
            $classes = explode('.', $matches[1]);
            $conditions = [];
            foreach ($classes as $class) {
                if (!empty($class)) {
                    $conditions[] = 'contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")';
                }
            }
            $xpath = '//*[' . implode(' and ', $conditions) . ']';
            if ($tag_filter) {
                $xpath = '//' . $tag_filter . '[' . implode(' and ', $conditions) . ']';
            }
            return $xpath;
        }

        // Handle nth-of-type selector
        if (preg_match('/^(\w+):nth-of-type\((\d+)\)$/', $selector, $matches)) {
            return '//' . $matches[1] . '[' . $matches[2] . ']';
        }

        // Default: treat as tag name
        if ($tag_filter) {
            return '//' . $tag_filter;
        }
        return '//' . $selector;
    }
}
