<?php
/**
 * Template Library & Wizard
 *
 * Handles sample template seeding and the Template Wizard admin page.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

use WP_Error;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Template Library Class
 */
class TemplateLibrary {
    /**
     * Option key that tracks sample template installations
     */
    private const OPTION_KEY = 'cf_html_template_samples';

    /**
     * Template origin meta key
     */
    private const META_ORIGIN = '_cf_template_origin';

    /**
     * Template slug meta key
     */
    private const META_SLUG = '_cf_template_slug';

    /**
     * Hook suffix for the Template Wizard page
     */
    private ?string $wizard_hook = null;

    /**
     * Image detector instance for generating placeholder mappings
     */
    private ImageDetector $detector;

    /**
     * Constructor
     */
    public function __construct(ImageDetector $detector) {
        $this->detector = $detector;
    }

    /**
     * Register admin pages under the ComplyFlow menu
     */
    public function register_admin_pages(): void {
        add_submenu_page(
            'complyflow',
            __('HTML Templates', 'complyflow'),
            __('HTML Templates', 'complyflow'),
            'manage_options',
            'complyflow-html-templates',
            [$this, 'redirect_to_templates'],
            15
        );

        $this->wizard_hook = add_submenu_page(
            'complyflow',
            __('Template Wizard', 'complyflow'),
            __('Template Wizard', 'complyflow'),
            'manage_options',
            'complyflow-template-wizard',
            [$this, 'render_wizard_page'],
            16
        );
    }

    /**
     * Enqueue assets for the Template Wizard page
     */
    public function enqueue_admin_assets(string $hook): void {
        if (empty($this->wizard_hook) || $hook !== $this->wizard_hook) {
            return;
        }

        wp_enqueue_style(
            'cf-template-wizard',
            COMPLYFLOW_URL . 'assets/src/css/admin/html-templates/template-wizard.css',
            [],
            COMPLYFLOW_VERSION
        );

        wp_enqueue_script(
            'cf-template-wizard',
            COMPLYFLOW_URL . 'assets/src/js/admin/html-templates/template-wizard.js',
            ['jquery'],
            COMPLYFLOW_VERSION,
            true
        );

        wp_localize_script('cf-template-wizard', 'cfTemplateWizard', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cf_template_wizard'),
            'strings' => [
                'importing' => __('Importing sample templates…', 'complyflow'),
                'imported' => __('Sample templates ready!', 'complyflow'),
                'error' => __('Unable to import templates. Please try again.', 'complyflow'),
                'copied' => __('Shortcode copied to clipboard', 'complyflow'),
                'button' => __('Import Sample Templates', 'complyflow'),
            ],
        ]);
    }

    /**
     * Redirect helper that opens the custom post type list
     */
    public function redirect_to_templates(): void {
        wp_safe_redirect(admin_url('edit.php?post_type=' . HTMLTemplateModule::POST_TYPE));
        exit;
    }

    /**
     * Render the Template Wizard screen
     */
    public function render_wizard_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to view this page.', 'complyflow'));
        }

        $templates = $this->get_templates();
        $stats = $this->get_template_stats($templates);
        $manage_url = admin_url('edit.php?post_type=' . HTMLTemplateModule::POST_TYPE);
        $create_url = admin_url('post-new.php?post_type=' . HTMLTemplateModule::POST_TYPE);
        ?>
        <div class="wrap cf-template-wizard-wrap">
            <h1><?php esc_html_e('Template Wizard', 'complyflow'); ?></h1>
            <p class="description">
                <?php esc_html_e('Landing HTML is sanitized automatically. Inline scripts and unsafe styles are removed for security.', 'complyflow'); ?>
            </p>

            <div class="cf-template-wizard-actions">
                <a href="<?php echo esc_url($create_url); ?>" class="button button-primary">
                    <?php esc_html_e('Create New Template', 'complyflow'); ?>
                </a>
                <a href="<?php echo esc_url($manage_url); ?>" class="button">
                    <?php esc_html_e('Manage Templates', 'complyflow'); ?>
                </a>
                <button type="button" class="button button-secondary" id="cf-import-templates">
                    <?php esc_html_e('Import Sample Templates', 'complyflow'); ?>
                </button>
            </div>

            <div id="cf-template-wizard-notice"></div>

            <?php if (empty($templates)) : ?>
                <div class="notice notice-warning inline">
                    <p><?php esc_html_e('No templates found. Click "Import Sample Templates" to install the starter library.', 'complyflow'); ?></p>
                </div>
            <?php else : ?>
                <div class="cf-template-wizard-summary">
                    <div class="cf-template-summary-card">
                        <span><?php esc_html_e('Total Templates', 'complyflow'); ?></span>
                        <strong><?php echo esc_html($stats['total']); ?></strong>
                    </div>
                    <div class="cf-template-summary-card">
                        <span><?php esc_html_e('Sample Library', 'complyflow'); ?></span>
                        <strong><?php echo esc_html($stats['sample']); ?></strong>
                    </div>
                    <div class="cf-template-summary-card">
                        <span><?php esc_html_e('Custom Templates', 'complyflow'); ?></span>
                        <strong><?php echo esc_html($stats['custom']); ?></strong>
                    </div>
                </div>

                <div class="cf-template-grid">
                    <?php foreach ($templates as $template) :
                        $is_sample = get_post_meta($template->ID, self::META_ORIGIN, true) === 'sample';
                        $shortcode = sprintf('[cf_template id="%d"]', $template->ID);
                        $description = $template->post_excerpt;
                        if (!$description) {
                            $html_content = get_post_meta($template->ID, '_cf_html_content', true);
                            $description = wp_trim_words(wp_strip_all_tags($html_content), 26);
                        }
                        ?>
                        <div class="cf-template-card <?php echo $is_sample ? 'is-sample' : 'is-custom'; ?>">
                            <div class="cf-template-card-header">
                                <span class="cf-template-badge">
                                    <?php echo $is_sample ? esc_html__('Sample', 'complyflow') : esc_html__('Custom', 'complyflow'); ?>
                                </span>
                                <h2><?php echo esc_html(get_the_title($template)); ?></h2>
                            </div>
                            <p class="cf-template-card-excerpt"><?php echo esc_html($description); ?></p>
                            <ul class="cf-template-card-meta">
                                <li>
                                    <strong><?php esc_html_e('Updated', 'complyflow'); ?>:</strong>
                                    <?php echo esc_html(get_the_modified_date('', $template)); ?>
                                </li>
                                <li>
                                    <strong><?php esc_html_e('Shortcode', 'complyflow'); ?>:</strong>
                                    <code><?php echo esc_html($shortcode); ?></code>
                                </li>
                            </ul>
                            <div class="cf-template-card-actions">
                                <a href="<?php echo esc_url(get_edit_post_link($template->ID)); ?>" class="button button-secondary">
                                    <?php esc_html_e('Edit Template', 'complyflow'); ?>
                                </a>
                                <button type="button" class="button cf-template-copy" data-shortcode="<?php echo esc_attr($shortcode); ?>">
                                    <?php esc_html_e('Copy Shortcode', 'complyflow'); ?>
                                </button>
                                <a href="<?php echo esc_url(add_query_arg([
                                    'action' => 'cf_export_template',
                                    'post_id' => $template->ID,
                                    'nonce' => wp_create_nonce('cf_html_template_nonce'),
                                ], admin_url('admin-ajax.php'))); ?>" class="button">
                                    <?php esc_html_e('Download HTML', 'complyflow'); ?>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="cf-template-wizard-help">
                <h2><?php esc_html_e('Need help?', 'complyflow'); ?></h2>
                <p><?php esc_html_e('Use the HTML Importer meta box to upload any landing page. After publishing, templates appear here automatically with shortcode access.', 'complyflow'); ?></p>
                <p>
                    <a href="<?php echo esc_url($manage_url); ?>" class="button-link">
                        <?php esc_html_e('View all templates', 'complyflow'); ?>
                    </a>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * Seed sample templates once per site
     */
    public function maybe_seed_samples(): void {
        $option = get_option(self::OPTION_KEY, []);
        $current_total = $this->get_template_count();

        if ($current_total > 0 && !empty($option)) {
            return;
        }

        $result = $this->seed_samples(false);
        if ($result['created'] > 0) {
            update_option(self::OPTION_KEY, [
                'version' => COMPLYFLOW_VERSION,
                'created' => current_time('mysql'),
            ]);
        }
    }

    /**
     * Seed templates immediately after plugin activation
     */
    public function seed_samples_on_activation(): void {
        $this->seed_samples(false);
    }

    /**
     * AJAX handler for manual seeding
     */
    public function ajax_seed_templates(): void {
        check_ajax_referer('cf_template_wizard', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'complyflow')]);
        }

        $result = $this->seed_samples(true);

        if (!empty($result['errors'])) {
            wp_send_json_error([
                'message' => __('Some templates could not be imported.', 'complyflow'),
                'errors' => $result['errors'],
            ]);
        }

        wp_send_json_success([
            'created' => $result['created'],
            'total' => $result['total'],
        ]);
    }

    /**
     * Seed the bundled sample templates
     */
    private function seed_samples(bool $force = false): array {
        if ($force) {
            $this->delete_sample_templates();
        }

        $definitions = $this->get_sample_definitions();
        $created = 0;
        $errors = [];

        foreach ($definitions as $sample) {
            if (!$force && $this->sample_exists($sample['slug'])) {
                continue;
            }

            $result = $this->create_sample_template($sample);

            if ($result instanceof WP_Error) {
                $errors[] = $result->get_error_message();
                continue;
            }

            if ($result > 0) {
                $created++;
            }
        }

        if ($created > 0) {
            update_option(self::OPTION_KEY, [
                'version' => COMPLYFLOW_VERSION,
                'created' => current_time('mysql'),
            ]);
        }

        return [
            'created' => $created,
            'errors' => $errors,
            'total' => count($definitions),
        ];
    }

    /**
     * Delete existing sample templates so they can be reinstalled cleanly
     */
    private function delete_sample_templates(): void {
        $posts = get_posts([
            'post_type' => HTMLTemplateModule::POST_TYPE,
            'post_status' => 'any',
            'nopaging' => true,
            'fields' => 'ids',
            'meta_key' => self::META_ORIGIN,
            'meta_value' => 'sample',
        ]);

        foreach ($posts as $post_id) {
            wp_delete_post($post_id, true);
        }
    }

    /**
     * Check if a sample template already exists
     */
    private function sample_exists(string $slug): bool {
        $existing = get_posts([
            'post_type' => HTMLTemplateModule::POST_TYPE,
            'post_status' => 'any',
            'meta_key' => self::META_SLUG,
            'meta_value' => $slug,
            'fields' => 'ids',
            'numberposts' => 1,
        ]);

        return !empty($existing);
    }

    /**
     * Create a template post from the provided sample definition
     */
    private function create_sample_template(array $sample) {
        $path = COMPLYFLOW_PATH . $sample['file'];

        if (!file_exists($path)) {
            return new WP_Error('cf_missing_sample', sprintf(__('Sample file %s not found.', 'complyflow'), $sample['file']));
        }

        $contents = file_get_contents($path);
        if ($contents === false) {
            return new WP_Error('cf_sample_read_error', sprintf(__('Unable to read %s.', 'complyflow'), $sample['file']));
        }

        $html = $this->sanitize_html($contents);

        $post_id = wp_insert_post([
            'post_title' => $sample['title'],
            'post_type' => HTMLTemplateModule::POST_TYPE,
            'post_status' => 'publish',
            'post_excerpt' => $sample['description'],
            'meta_input' => [
                '_cf_html_content' => $html,
                '_cf_html_file_name' => $sample['file'],
                '_cf_template_origin' => 'sample',
                '_cf_template_slug' => $sample['slug'],
                '_cf_html_uploaded_at' => current_time('mysql'),
            ],
        ]);

        if (is_wp_error($post_id)) {
            return $post_id;
        }

        $mappings = $this->detector->detect($html);
        update_post_meta($post_id, '_cf_image_mappings', $mappings);

        return $post_id;
    }

    /**
     * Retrieve all template posts for the wizard view
     */
    private function get_templates(): array {
        return get_posts([
            'post_type' => HTMLTemplateModule::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending'],
            'orderby' => 'modified',
            'order' => 'DESC',
            'numberposts' => -1,
        ]);
    }

    /**
     * Calculate template statistics for the dashboard cards
     */
    private function get_template_stats(array $templates): array {
        $stats = [
            'total' => count($templates),
            'sample' => 0,
            'custom' => 0,
        ];

        foreach ($templates as $template) {
            $is_sample = get_post_meta($template->ID, self::META_ORIGIN, true) === 'sample';
            if ($is_sample) {
                $stats['sample']++;
            } else {
                $stats['custom']++;
            }
        }

        return $stats;
    }

    /**
     * Count published templates
     */
    private function get_template_count(): int {
        $counts = wp_count_posts(HTMLTemplateModule::POST_TYPE);
        return $counts && isset($counts->publish) ? (int) $counts->publish : 0;
    }

    /**
     * Sample template metadata
     */
    private function get_sample_definitions(): array {
        return [
            [
                'slug' => 'acme-saas-launch',
                'title' => __('Acme SaaS Launch', 'complyflow'),
                'file' => 'landing-page.html',
                'description' => __('Premium SaaS hero layout with conversion-focused feature grid, KPI highlights, pricing tiers, and testimonial slider.', 'complyflow'),
            ],
            [
                'slug' => 'stellar-app-ignite',
                'title' => __('Stellar App Ignite', 'complyflow'),
                'file' => 'landing-page02.html',
                'description' => __('Gradient-powered mobile app landing page with device mockups, animated counters, FAQ accordion, and dual CTA sections.', 'complyflow'),
            ],
        ];
    }

    /**
     * Sanitize bundled HTML similar to the importer
     */
    private function sanitize_html(string $html): string {
        $html = preg_replace('/^\xEF\xBB\xBF/', '', $html);
        $html = str_replace(["\r\n", "\r"], "\n", $html);
        $html = preg_replace('/<\?php.*?\?>/is', '', $html);

        return $html;
    }
}
