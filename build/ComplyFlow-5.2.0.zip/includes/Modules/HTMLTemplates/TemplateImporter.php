<?php
/**
 * Template Importer
 *
 * Handles HTML file uploads and validation.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Template Importer Class
 *
 * @since 5.2.0
 */
class TemplateImporter {
    /**
     * Maximum file size in bytes (5MB)
     *
     * @var int
     */
    private const MAX_FILE_SIZE = 5242880;

    /**
     * Allowed MIME types
     *
     * @var array
     */
    private const ALLOWED_MIME_TYPES = [
        'text/html',
        'text/plain',
        'application/octet-stream', // Some servers report HTML as this
    ];

    /**
     * Import HTML template from uploaded file
     *
     * @param array $file $_FILES array entry.
     * @return array Result array with 'success', 'html', 'filename', 'error'.
     */
    public function import(array $file): array {
        // Validate file upload
        $validation = $this->validate_upload($file);
        if (!$validation['success']) {
            return $validation;
        }

        // Read file content
        $html = file_get_contents($file['tmp_name']);
        if ($html === false) {
            return [
                'success' => false,
                'error' => __('Failed to read uploaded file.', 'complyflow'),
            ];
        }

        // Validate HTML content
        $content_validation = $this->validate_html_content($html);
        if (!$content_validation['success']) {
            return $content_validation;
        }

        // Sanitize HTML
        $sanitized_html = $this->sanitize_html($html);

        return [
            'success' => true,
            'html' => $sanitized_html,
            'filename' => sanitize_file_name($file['name']),
            'size' => $file['size'],
        ];
    }

    /**
     * Validate uploaded file
     *
     * @param array $file $_FILES array entry.
     * @return array Validation result.
     */
    private function validate_upload(array $file): array {
        // Check for upload errors
        if (!isset($file['error']) || is_array($file['error'])) {
            return [
                'success' => false,
                'error' => __('Invalid file upload.', 'complyflow'),
            ];
        }

        switch ($file['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return [
                    'success' => false,
                    'error' => __('File size exceeds maximum limit.', 'complyflow'),
                ];
            case UPLOAD_ERR_NO_FILE:
                return [
                    'success' => false,
                    'error' => __('No file was uploaded.', 'complyflow'),
                ];
            default:
                return [
                    'success' => false,
                    'error' => __('Unknown upload error.', 'complyflow'),
                ];
        }

        // Check file size
        if ($file['size'] > self::MAX_FILE_SIZE) {
            return [
                'success' => false,
                'error' => sprintf(
                    /* translators: %s: Maximum file size in MB */
                    __('File size exceeds maximum limit of %s MB.', 'complyflow'),
                    number_format(self::MAX_FILE_SIZE / 1048576, 1)
                ),
            ];
        }

        // Check MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime_type = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mime_type, self::ALLOWED_MIME_TYPES, true)) {
            // Additional check: verify file extension
            $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if (!in_array($file_extension, ['html', 'htm'], true)) {
                return [
                    'success' => false,
                    'error' => __('Invalid file type. Only HTML files are allowed.', 'complyflow'),
                ];
            }
        }

        // Check if file is actually uploaded
        if (!is_uploaded_file($file['tmp_name'])) {
            return [
                'success' => false,
                'error' => __('Security validation failed.', 'complyflow'),
            ];
        }

        return ['success' => true];
    }

    /**
     * Validate HTML content
     *
     * @param string $html HTML content.
     * @return array Validation result.
     */
    private function validate_html_content(string $html): array {
        // Check if content is empty
        if (empty(trim($html))) {
            return [
                'success' => false,
                'error' => __('Uploaded file is empty.', 'complyflow'),
            ];
        }

        // Check for minimum HTML structure
        if (!preg_match('/<[^>]+>/i', $html)) {
            return [
                'success' => false,
                'error' => __('File does not contain valid HTML.', 'complyflow'),
            ];
        }

        // Check for dangerous content
        if ($this->contains_dangerous_content($html)) {
            return [
                'success' => false,
                'error' => __('File contains potentially dangerous content.', 'complyflow'),
            ];
        }

        return ['success' => true];
    }

    /**
     * Check for dangerous content
     *
     * @param string $html HTML content.
     * @return bool True if dangerous content found.
     */
    private function contains_dangerous_content(string $html): bool {
        // Check for PHP tags
        if (preg_match('/<\?php/i', $html)) {
            return true;
        }

        // Check for dangerous JavaScript patterns
        $dangerous_patterns = [
            '/<script[^>]*>.*?eval\s*\(/is',
            '/<script[^>]*>.*?document\.write\s*\(/is',
            '/on(?:load|error|click|mouse\w+)\s*=\s*["\'].*?(?:eval|document\.write)/i',
            '/<iframe[^>]+src\s*=\s*["\'](?:javascript|data):/i',
        ];

        foreach ($dangerous_patterns as $pattern) {
            if (preg_match($pattern, $html)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Sanitize HTML content
     *
     * @param string $html HTML content.
     * @return string Sanitized HTML.
     */
    private function sanitize_html(string $html): string {
        // Remove BOM if present
        $html = preg_replace('/^\xEF\xBB\xBF/', '', $html);

        // Normalize line endings
        $html = str_replace(["\r\n", "\r"], "\n", $html);

        // Remove PHP tags just in case
        $html = preg_replace('/<\?php.*?\?>/is', '', $html);

        return $html;
    }

    /**
     * Import HTML from URL
     *
     * @param string $url URL to fetch HTML from.
     * @return array Result array.
     */
    public function import_from_url(string $url): array {
        // Validate URL
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return [
                'success' => false,
                'error' => __('Invalid URL provided.', 'complyflow'),
            ];
        }

        // Fetch content
        $response = wp_remote_get($url, [
            'timeout' => 30,
            'user-agent' => 'ComplyFlow HTML Template Importer',
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'error' => sprintf(
                    /* translators: %s: Error message */
                    __('Failed to fetch URL: %s', 'complyflow'),
                    $response->get_error_message()
                ),
            ];
        }

        $html = wp_remote_retrieve_body($response);

        // Validate content
        $validation = $this->validate_html_content($html);
        if (!$validation['success']) {
            return $validation;
        }

        // Sanitize HTML
        $sanitized_html = $this->sanitize_html($html);

        return [
            'success' => true,
            'html' => $sanitized_html,
            'filename' => basename(parse_url($url, PHP_URL_PATH)),
            'size' => strlen($sanitized_html),
        ];
    }
}
