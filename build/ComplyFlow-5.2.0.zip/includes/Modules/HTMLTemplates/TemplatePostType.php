<?php
/**
 * Template Custom Post Type
 *
 * Registers and manages the HTML template custom post type.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Template Post Type Class
 *
 * @since 5.2.0
 */
class TemplatePostType {
    /**
     * Register custom post type
     *
     * @return void
     */
    public function register(): void {
        register_post_type(HTMLTemplateModule::POST_TYPE, [
            'labels' => [
                'name' => __('HTML Templates', 'complyflow'),
                'singular_name' => __('HTML Template', 'complyflow'),
                'add_new' => __('Add New Template', 'complyflow'),
                'add_new_item' => __('Add New HTML Template', 'complyflow'),
                'edit_item' => __('Edit HTML Template', 'complyflow'),
                'new_item' => __('New HTML Template', 'complyflow'),
                'view_item' => __('View HTML Template', 'complyflow'),
                'search_items' => __('Search HTML Templates', 'complyflow'),
                'not_found' => __('No HTML templates found', 'complyflow'),
                'not_found_in_trash' => __('No HTML templates found in trash', 'complyflow'),
                'all_items' => __('All HTML Templates', 'complyflow'),
                'menu_name' => __('HTML Templates', 'complyflow'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'complyflow',
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => ['title', 'revisions'],
            'has_archive' => false,
            'rewrite' => false,
            'query_var' => false,
            'menu_icon' => 'dashicons-media-code',
            'show_in_rest' => false,
        ]);
    }

    /**
     * Add meta boxes
     *
     * @return void
     */
    public function add_meta_boxes(): void {
        add_meta_box(
            'cf_template_upload',
            __('HTML Template File', 'complyflow'),
            [$this, 'render_upload_meta_box'],
            HTMLTemplateModule::POST_TYPE,
            'normal',
            'high'
        );

        add_meta_box(
            'cf_template_images',
            __('Image Mappings', 'complyflow'),
            [$this, 'render_images_meta_box'],
            HTMLTemplateModule::POST_TYPE,
            'normal',
            'high'
        );

        add_meta_box(
            'cf_template_preview',
            __('Template Preview & Export', 'complyflow'),
            [$this, 'render_preview_meta_box'],
            HTMLTemplateModule::POST_TYPE,
            'side',
            'default'
        );

        add_meta_box(
            'cf_template_shortcode',
            __('Shortcode', 'complyflow'),
            [$this, 'render_shortcode_meta_box'],
            HTMLTemplateModule::POST_TYPE,
            'side',
            'default'
        );
    }

    /**
     * Render upload meta box
     *
     * @param \WP_Post $post Current post object.
     * @return void
     */
    public function render_upload_meta_box(\WP_Post $post): void {
        wp_nonce_field('cf_template_meta_box', 'cf_template_meta_box_nonce');
        
        $html_content = get_post_meta($post->ID, '_cf_html_content', true);
        $file_name = get_post_meta($post->ID, '_cf_html_file_name', true);
        
        ?>
        <div class="cf-template-upload-section">
            <div class="cf-upload-area" id="cf-upload-area">
                <input type="file" id="cf-html-file-input" accept=".html,.htm" style="display:none;">
                <button type="button" class="button button-primary button-large" id="cf-upload-btn">
                    <span class="dashicons dashicons-upload"></span>
                    <?php esc_html_e('Upload HTML File', 'complyflow'); ?>
                </button>
                <?php if ($file_name): ?>
                    <p class="description">
                        <?php
                        printf(
                            /* translators: %s: File name */
                            esc_html__('Current file: %s', 'complyflow'),
                            '<code>' . esc_html($file_name) . '</code>'
                        );
                        ?>
                    </p>
                <?php endif; ?>
            </div>
            
            <div class="cf-upload-progress" id="cf-upload-progress" style="display:none;">
                <div class="cf-progress-bar">
                    <div class="cf-progress-fill"></div>
                </div>
                <p class="description"><?php esc_html_e('Uploading...', 'complyflow'); ?></p>
            </div>
            
            <div class="cf-upload-success" id="cf-upload-success" style="display:none;">
                <p class="notice notice-success inline">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php esc_html_e('Template uploaded successfully! Click "Detect Images" to continue.', 'complyflow'); ?>
                </p>
            </div>
            
            <div class="cf-upload-error" id="cf-upload-error" style="display:none;">
                <p class="notice notice-error inline">
                    <span class="dashicons dashicons-warning"></span>
                    <span class="error-message"></span>
                </p>
            </div>

            <?php if ($html_content): ?>
                <div class="cf-template-actions" style="margin-top: 15px;">
                    <button type="button" class="button" id="cf-detect-images-btn">
                        <span class="dashicons dashicons-search"></span>
                        <?php esc_html_e('Detect Images', 'complyflow'); ?>
                    </button>
                    <button type="button" class="button" id="cf-view-source-btn">
                        <span class="dashicons dashicons-editor-code"></span>
                        <?php esc_html_e('View Source', 'complyflow'); ?>
                    </button>
                </div>

                <div class="cf-source-viewer" id="cf-source-viewer" style="display:none; margin-top: 15px;">
                    <textarea readonly style="width:100%; height:300px; font-family:monospace; font-size:12px;"><?php echo esc_textarea($html_content); ?></textarea>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render images meta box
     *
     * @param \WP_Post $post Current post object.
     * @return void
     */
    public function render_images_meta_box(\WP_Post $post): void {
        $html_content = get_post_meta($post->ID, '_cf_html_content', true);
        $mappings = get_post_meta($post->ID, '_cf_image_mappings', true) ?: [];
        
        if (!$html_content) {
            ?>
            <p class="description">
                <?php esc_html_e('Upload an HTML template first to detect images.', 'complyflow'); ?>
            </p>
            <?php
            return;
        }
        ?>
        
        <div class="cf-images-section">
            <div id="cf-images-detected" style="display:none;">
                <p class="notice notice-info inline">
                    <span class="dashicons dashicons-info"></span>
                    <span id="cf-images-count">0</span> <?php esc_html_e('image placeholder(s) detected.', 'complyflow'); ?>
                </p>
            </div>

            <div id="cf-no-images" style="display:<?php echo empty($mappings) ? 'block' : 'none'; ?>;">
                <p class="description">
                    <?php esc_html_e('Click "Detect Images" to scan the template for image placeholders.', 'complyflow'); ?>
                </p>
            </div>

            <div id="cf-images-list" <?php echo empty($mappings) ? 'style="display:none;"' : ''; ?>>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 25%;"><?php esc_html_e('Placeholder', 'complyflow'); ?></th>
                            <th style="width: 15%;"><?php esc_html_e('Type', 'complyflow'); ?></th>
                            <th style="width: 40%;"><?php esc_html_e('Image Source', 'complyflow'); ?></th>
                            <th style="width: 20%;"><?php esc_html_e('Actions', 'complyflow'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="cf-images-tbody">
                        <?php if (!empty($mappings)): ?>
                            <?php foreach ($mappings as $index => $mapping): ?>
                                <tr data-image-id="<?php echo esc_attr($mapping['id']); ?>">
                                    <td>
                                        <code class="cf-selector"><?php echo esc_html($mapping['selector'] ?? ''); ?></code>
                                    </td>
                                    <td>
                                        <span class="cf-type-badge">
                                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $mapping['type'] ?? 'img_tag'))); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <input type="url" 
                                               class="regular-text cf-image-url" 
                                               value="<?php echo esc_url($mapping['url']); ?>" 
                                               placeholder="<?php esc_attr_e('Enter image URL or select from library', 'complyflow'); ?>">
                                        <?php if (!empty($mapping['url'])): ?>
                                            <div class="cf-image-preview" style="margin-top: 5px;">
                                                <img src="<?php echo esc_url($mapping['url']); ?>" 
                                                     style="max-width: 100px; max-height: 100px; border: 1px solid #ddd;">
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="button button-small cf-choose-image" data-image-id="<?php echo esc_attr($mapping['id']); ?>">
                                            <span class="dashicons dashicons-format-image"></span>
                                            <?php esc_html_e('Choose', 'complyflow'); ?>
                                        </button>
                                        <button type="button" class="button button-small cf-clear-image" data-image-id="<?php echo esc_attr($mapping['id']); ?>">
                                            <span class="dashicons dashicons-no"></span>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="cf-save-mappings" style="margin-top: 15px;">
                    <button type="button" class="button button-primary" id="cf-save-mappings-btn">
                        <span class="dashicons dashicons-saved"></span>
                        <?php esc_html_e('Save Image Mappings', 'complyflow'); ?>
                    </button>
                    <span class="spinner" id="cf-save-spinner"></span>
                    <span class="cf-save-status" id="cf-save-status"></span>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render preview meta box
     *
     * @param \WP_Post $post Current post object.
     * @return void
     */
    public function render_preview_meta_box(\WP_Post $post): void {
        $html_content = get_post_meta($post->ID, '_cf_html_content', true);
        
        if (!$html_content) {
            ?>
            <p class="description">
                <?php esc_html_e('Upload a template to enable preview and export.', 'complyflow'); ?>
            </p>
            <?php
            return;
        }
        ?>
        
        <div class="cf-preview-section">
            <p>
                <button type="button" class="button button-large button-secondary" id="cf-preview-btn" style="width: 100%;">
                    <span class="dashicons dashicons-visibility"></span>
                    <?php esc_html_e('Preview Template', 'complyflow'); ?>
                </button>
            </p>
            
            <p>
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-ajax.php?action=cf_export_template&post_id=' . $post->ID), 'cf_html_template_nonce', 'nonce')); ?>" 
                   class="button button-large" 
                   style="width: 100%;">
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e('Export HTML', 'complyflow'); ?>
                </a>
            </p>
            
            <div class="cf-template-stats" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ddd;">
                <?php
                $mappings = get_post_meta($post->ID, '_cf_image_mappings', true) ?: [];
                $mapped_count = count(array_filter($mappings, function($m) {
                    return !empty($m['url']);
                }));
                ?>
                <p class="description">
                    <strong><?php esc_html_e('Images:', 'complyflow'); ?></strong> 
                    <?php echo esc_html($mapped_count . ' / ' . count($mappings)); ?> <?php esc_html_e('mapped', 'complyflow'); ?>
                </p>
                <p class="description">
                    <strong><?php esc_html_e('Modified:', 'complyflow'); ?></strong> 
                    <?php echo esc_html(get_the_modified_date('', $post)); ?>
                </p>
            </div>
        </div>
        
        <div id="cf-preview-modal" class="cf-modal" style="display:none;">
            <div class="cf-modal-content">
                <span class="cf-modal-close">&times;</span>
                <h2><?php esc_html_e('Template Preview', 'complyflow'); ?></h2>
                <iframe id="cf-preview-frame" style="width:100%; height:600px; border:1px solid #ddd;"></iframe>
            </div>
        </div>
        <?php
    }

    /**
     * Render shortcode meta box
     *
     * @param \WP_Post $post Current post object.
     * @return void
     */
    public function render_shortcode_meta_box(\WP_Post $post): void {
        if ($post->post_status !== 'publish') {
            ?>
            <p class="description">
                <?php esc_html_e('Publish this template to get the shortcode.', 'complyflow'); ?>
            </p>
            <?php
            return;
        }
        ?>
        
        <div class="cf-shortcode-section">
            <p>
                <label for="cf-shortcode-input"><?php esc_html_e('Use this shortcode:', 'complyflow'); ?></label>
                <input type="text" 
                       id="cf-shortcode-input" 
                       readonly 
                       value='[cf_template id="<?php echo esc_attr($post->ID); ?>"]' 
                       class="widefat code" 
                       style="font-family: monospace;">
            </p>
            <p>
                <button type="button" class="button button-secondary" id="cf-copy-shortcode-btn" style="width: 100%;">
                    <span class="dashicons dashicons-admin-page"></span>
                    <?php esc_html_e('Copy to Clipboard', 'complyflow'); ?>
                </button>
            </p>
            <p class="description">
                <?php esc_html_e('Paste this shortcode into any post or page to display this template.', 'complyflow'); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Save meta boxes
     *
     * @param int      $post_id Post ID.
     * @param \WP_Post $post    Post object.
     * @return void
     */
    public function save_meta_boxes(int $post_id, \WP_Post $post): void {
        // Verify nonce
        if (!isset($_POST['cf_template_meta_box_nonce']) || 
            !wp_verify_nonce($_POST['cf_template_meta_box_nonce'], 'cf_template_meta_box')) {
            return;
        }

        // Check autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Note: File upload and image mappings are handled via AJAX
        // This method is kept for future expansion if needed
    }
}
