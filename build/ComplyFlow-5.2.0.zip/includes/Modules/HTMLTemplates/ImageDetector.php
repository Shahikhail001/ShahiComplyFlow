<?php
/**
 * Image Detector
 *
 * Detects image placeholders in HTML templates using multiple detection methods.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Image Detector Class
 *
 * @since 5.2.0
 */
class ImageDetector {
    /**
     * Detect image placeholders in HTML content
     *
     * @param string $html HTML content to analyze.
     * @return array Array of detected image placeholders.
     */
    public function detect(string $html): array {
        if (empty($html)) {
            return [];
        }

        $images = [];
        $dom = new \DOMDocument();
        
        // Suppress HTML5 warnings
        libxml_use_internal_errors(true);
        $dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIES | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        
        $xpath = new \DOMXPath($dom);

        // Detection Method 1: IMG tags with placeholder-like src
        $images = array_merge($images, $this->detect_img_tags($xpath));

        // Detection Method 2: Background images in inline styles
        $images = array_merge($images, $this->detect_background_images($xpath));

        // Detection Method 3: Data attributes for images
        $images = array_merge($images, $this->detect_data_attributes($xpath));

        // Detection Method 4: Picture/source elements
        $images = array_merge($images, $this->detect_picture_elements($xpath));

        // Remove duplicates based on selector
        $unique_images = [];
        $seen_selectors = [];
        
        foreach ($images as $image) {
            $key = $image['selector'] . '_' . $image['type'];
            if (!isset($seen_selectors[$key])) {
                $seen_selectors[$key] = true;
                $unique_images[] = $image;
            }
        }

        return $unique_images;
    }

    /**
     * Detect IMG tags with placeholder sources
     *
     * @param \DOMXPath $xpath XPath instance.
     * @return array Detected images.
     */
    private function detect_img_tags(\DOMXPath $xpath): array {
        $images = [];
        
        // Query for images with placeholder-like patterns or missing src
        $queries = [
            '//img[contains(@src, "placeholder")]',
            '//img[contains(@src, "via.placeholder")]',
            '//img[contains(@src, "placehold")]',
            '//img[contains(@src, "lorempixel")]',
            '//img[contains(@src, "unsplash.it")]',
            '//img[contains(@src, "picsum")]',
            '//img[not(@src) or @src=""]',
            '//img[starts-with(@src, "data:image")]',
            '//img[contains(@src, "example.com")]',
            '//img[contains(@class, "placeholder")]',
        ];

        foreach ($queries as $query) {
            $nodes = @$xpath->query($query);
            if (!$nodes) {
                continue;
            }

            foreach ($nodes as $index => $node) {
                $src = $node->getAttribute('src');
                $alt = $node->getAttribute('alt');
                $class = $node->getAttribute('class');
                $id = $node->getAttribute('id');

                // Generate unique selector
                $selector = $this->generate_selector($node, $index);

                $images[] = [
                    'id' => 'img_' . md5($selector . $src),
                    'type' => 'img_tag',
                    'selector' => $selector,
                    'current_value' => $src,
                    'alt' => $alt,
                    'class' => $class,
                    'element_id' => $id,
                    'url' => '',
                ];
            }
        }

        return $images;
    }

    /**
     * Detect background images in inline styles
     *
     * @param \DOMXPath $xpath XPath instance.
     * @return array Detected images.
     */
    private function detect_background_images(\DOMXPath $xpath): array {
        $images = [];
        
        // Find elements with background-image in style attribute
        $nodes = @$xpath->query('//*[@style]');
        if (!$nodes) {
            return [];
        }

        foreach ($nodes as $index => $node) {
            $style = $node->getAttribute('style');
            
            // Check if style contains background-image
            if (preg_match('/background(?:-image)?\s*:\s*url\(["\']?([^"\')]+)["\']?\)/i', $style, $matches)) {
                $url = $matches[1];
                
                // Only detect placeholder-like URLs
                if ($this->is_placeholder_url($url)) {
                    $selector = $this->generate_selector($node, $index);
                    
                    $images[] = [
                        'id' => 'bg_' . md5($selector . $url),
                        'type' => 'background_image',
                        'selector' => $selector,
                        'current_value' => $url,
                        'alt' => '',
                        'class' => $node->getAttribute('class'),
                        'element_id' => $node->getAttribute('id'),
                        'url' => '',
                    ];
                }
            }
        }

        return $images;
    }

    /**
     * Detect data attributes for images
     *
     * @param \DOMXPath $xpath XPath instance.
     * @return array Detected images.
     */
    private function detect_data_attributes(\DOMXPath $xpath): array {
        $images = [];
        
        $data_attrs = ['data-src', 'data-image', 'data-bg', 'data-background'];
        
        foreach ($data_attrs as $attr) {
            $nodes = @$xpath->query('//*[@' . $attr . ']');
            if (!$nodes) {
                continue;
            }

            foreach ($nodes as $index => $node) {
                $value = $node->getAttribute($attr);
                
                if ($this->is_placeholder_url($value) || empty($value)) {
                    $selector = $this->generate_selector($node, $index);
                    
                    $images[] = [
                        'id' => 'data_' . md5($selector . $attr),
                        'type' => 'data_attribute',
                        'selector' => $selector,
                        'attribute' => $attr,
                        'current_value' => $value,
                        'alt' => '',
                        'class' => $node->getAttribute('class'),
                        'element_id' => $node->getAttribute('id'),
                        'url' => '',
                    ];
                }
            }
        }

        return $images;
    }

    /**
     * Detect picture/source elements
     *
     * @param \DOMXPath $xpath XPath instance.
     * @return array Detected images.
     */
    private function detect_picture_elements(\DOMXPath $xpath): array {
        $images = [];
        
        $nodes = @$xpath->query('//picture//source[@srcset]');
        if (!$nodes) {
            return [];
        }

        foreach ($nodes as $index => $node) {
            $srcset = $node->getAttribute('srcset');
            
            if ($this->is_placeholder_url($srcset) || empty($srcset)) {
                $selector = $this->generate_selector($node, $index);
                
                $images[] = [
                    'id' => 'source_' . md5($selector),
                    'type' => 'source_srcset',
                    'selector' => $selector,
                    'current_value' => $srcset,
                    'alt' => '',
                    'class' => $node->getAttribute('class'),
                    'element_id' => $node->getAttribute('id'),
                    'url' => '',
                ];
            }
        }

        return $images;
    }

    /**
     * Check if URL is a placeholder
     *
     * @param string $url URL to check.
     * @return bool True if placeholder URL.
     */
    private function is_placeholder_url(string $url): bool {
        if (empty($url)) {
            return true;
        }

        $placeholder_patterns = [
            'placeholder',
            'placehold',
            'lorempixel',
            'unsplash.it',
            'picsum',
            'via.placeholder',
            'example.com',
            'data:image',
        ];

        foreach ($placeholder_patterns as $pattern) {
            if (stripos($url, $pattern) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Generate CSS selector for element
     *
     * @param \DOMNode $node     DOM node.
     * @param int      $index    Element index.
     * @return string CSS selector.
     */
    private function generate_selector(\DOMNode $node, int $index = 0): string {
        // Prefer ID
        if ($node->hasAttribute && $node->hasAttribute('id')) {
            return '#' . $node->getAttribute('id');
        }

        // Use class names
        if ($node->hasAttribute && $node->hasAttribute('class')) {
            $classes = explode(' ', $node->getAttribute('class'));
            $classes = array_filter($classes);
            if (!empty($classes)) {
                return '.' . implode('.', array_slice($classes, 0, 2));
            }
        }

        // Fallback to tag name with nth-child
        $tag_name = $node->nodeName;
        return $tag_name . ':nth-of-type(' . ($index + 1) . ')';
    }
}
