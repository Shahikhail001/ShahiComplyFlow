<?php
/**
 * Template Renderer
 *
 * Renders HTML templates with image replacements.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Template Renderer Class
 *
 * @since 5.2.0
 */
class TemplateRenderer {
    /**
     * Image replacer instance
     *
     * @var ImageReplacer
     */
    private ImageReplacer $replacer;

    /**
     * Constructor
     */
    public function __construct() {
        $this->replacer = new ImageReplacer();
    }

    /**
     * Render template by post ID
     *
     * @param int   $post_id Template post ID.
     * @param array $args    Optional rendering arguments.
     * @return string Rendered HTML.
     */
    public function render(int $post_id, array $args = []): string {
        // Get post
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'cf_html_template') {
            return '';
        }

        // Check if published or user has permission
        if ($post->post_status !== 'publish' && !current_user_can('edit_post', $post_id)) {
            return '';
        }

        // Get HTML content
        $html = get_post_meta($post_id, '_cf_html_content', true);
        if (empty($html)) {
            return '';
        }

        // Get image mappings
        $mappings = get_post_meta($post_id, '_cf_image_mappings', true);
        if (!is_array($mappings)) {
            $mappings = [];
        }

        // Filter mappings to only include those with URLs
        $mappings = array_filter($mappings, function($mapping) {
            return !empty($mapping['url']);
        });

        // Apply image replacements
        if (!empty($mappings)) {
            $html = $this->replacer->replace($html, $mappings);
        }

        // Apply filters
        $html = apply_filters('complyflow_html_template_render', $html, $post_id, $args);

        // Wrap in container if requested
        if (!empty($args['wrap'])) {
            $container_class = !empty($args['container_class']) 
                ? esc_attr($args['container_class']) 
                : 'cf-html-template';
            
            $html = sprintf(
                '<div class="%s" data-template-id="%d">%s</div>',
                $container_class,
                $post_id,
                $html
            );
        }

        return $html;
    }

    /**
     * Preview template (admin only)
     *
     * @param int $post_id Template post ID.
     * @return string Preview HTML with admin styles.
     */
    public function preview(int $post_id): string {
        if (!current_user_can('edit_post', $post_id)) {
            return '';
        }

        $html = $this->render($post_id);
        if (empty($html)) {
            return '<p>' . esc_html__('No template content available.', 'complyflow') . '</p>';
        }

        // Wrap in preview container
        $preview_html = sprintf(
            '<div class="cf-template-preview">
                <div class="cf-template-preview-header">
                    <h3>%s</h3>
                </div>
                <div class="cf-template-preview-content">
                    %s
                </div>
            </div>',
            esc_html__('Template Preview', 'complyflow'),
            $html
        );

        return $preview_html;
    }

    /**
     * Export template with replaced images
     *
     * @param int $post_id Template post ID.
     * @return array Export result with 'success', 'html', 'filename'.
     */
    public function export(int $post_id): array {
        if (!current_user_can('edit_post', $post_id)) {
            return [
                'success' => false,
                'error' => __('Permission denied.', 'complyflow'),
            ];
        }

        $html = $this->render($post_id);
        if (empty($html)) {
            return [
                'success' => false,
                'error' => __('No template content to export.', 'complyflow'),
            ];
        }

        // Get original filename or generate one
        $original_filename = get_post_meta($post_id, '_cf_html_file_name', true);
        if (empty($original_filename)) {
            $post = get_post($post_id);
            $original_filename = sanitize_file_name($post->post_title) . '.html';
        }

        // Generate export filename
        $filename = str_replace('.html', '', $original_filename);
        $filename .= '-exported-' . date('Y-m-d-His') . '.html';

        return [
            'success' => true,
            'html' => $html,
            'filename' => $filename,
        ];
    }

    /**
     * Get template statistics
     *
     * @param int $post_id Template post ID.
     * @return array Statistics array.
     */
    public function get_stats(int $post_id): array {
        $html = get_post_meta($post_id, '_cf_html_content', true);
        $mappings = get_post_meta($post_id, '_cf_image_mappings', true);
        
        if (!is_array($mappings)) {
            $mappings = [];
        }

        $mapped_count = 0;
        foreach ($mappings as $mapping) {
            if (!empty($mapping['url'])) {
                $mapped_count++;
            }
        }

        return [
            'total_images' => count($mappings),
            'mapped_images' => $mapped_count,
            'unmapped_images' => count($mappings) - $mapped_count,
            'html_size' => strlen($html),
            'completion_percent' => count($mappings) > 0 
                ? round(($mapped_count / count($mappings)) * 100) 
                : 100,
        ];
    }

    /**
     * Validate template before rendering
     *
     * @param int $post_id Template post ID.
     * @return array Validation result.
     */
    public function validate(int $post_id): array {
        $issues = [];

        // Check HTML content exists
        $html = get_post_meta($post_id, '_cf_html_content', true);
        if (empty($html)) {
            $issues[] = __('No HTML content found.', 'complyflow');
        }

        // Check for unmapped images
        $mappings = get_post_meta($post_id, '_cf_image_mappings', true);
        if (is_array($mappings)) {
            $unmapped = array_filter($mappings, function($mapping) {
                return empty($mapping['url']);
            });

            if (!empty($unmapped)) {
                $issues[] = sprintf(
                    /* translators: %d: Number of unmapped images */
                    _n(
                        '%d image is not mapped.',
                        '%d images are not mapped.',
                        count($unmapped),
                        'complyflow'
                    ),
                    count($unmapped)
                );
            }
        }

        return [
            'valid' => empty($issues),
            'issues' => $issues,
        ];
    }
}
