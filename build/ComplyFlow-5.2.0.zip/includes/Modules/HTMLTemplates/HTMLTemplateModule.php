<?php
/**
 * HTML Template Module
 *
 * Manages custom HTML templates with dynamic image replacement capabilities.
 * Allows users to upload HTML files, detect image placeholders, and replace them
 * with Media Library images or external URLs.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * HTML Template Module Class
 *
 * @since 5.2.0
 */
class HTMLTemplateModule {
    /**
     * Custom post type name
     *
     * @var string
     */
    const POST_TYPE = 'cf_html_template';

    /**
     * Template post type instance
     *
     * @var TemplatePostType
     */
    private TemplatePostType $post_type;

    /**
     * Template importer instance
     *
     * @var TemplateImporter
     */
    private TemplateImporter $importer;

    /**
     * Template renderer instance
     *
     * @var TemplateRenderer
     */
    private TemplateRenderer $renderer;

    /**
     * Image detector instance
     *
     * @var ImageDetector
     */
    private ImageDetector $detector;

    /**
     * Image replacer instance
     *
     * @var ImageReplacer
     */
    private ImageReplacer $replacer;

    /**
     * Shortcode handler instance
     *
     * @var ShortcodeHandler
     */
    private ShortcodeHandler $shortcode;

    /**
     * Template library instance
     *
     * @var TemplateLibrary
     */
    private TemplateLibrary $library;

    /**
     * Constructor
     */
    public function __construct() {
        $this->post_type = new TemplatePostType();
        $this->importer = new TemplateImporter();
        $this->detector = new ImageDetector();
        $this->replacer = new ImageReplacer();
        $this->renderer = new TemplateRenderer($this->replacer);
        $this->shortcode = new ShortcodeHandler($this->renderer);
        $this->library = new TemplateLibrary($this->detector);
    }

    /**
     * Initialize the module
     *
     * @return void
     */
    public function init(): void {
        // Register custom post type
        add_action('init', [$this->post_type, 'register']);
        
        // Initialize shortcode
        add_action('init', [$this->shortcode, 'init']);
        
        // Admin hooks
        if (is_admin()) {
            add_action('add_meta_boxes', [$this->post_type, 'add_meta_boxes']);
            add_action('save_post_' . self::POST_TYPE, [$this->post_type, 'save_meta_boxes'], 10, 2);
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
            add_action('admin_enqueue_scripts', [$this->library, 'enqueue_admin_assets']);
            add_action('admin_menu', [$this->library, 'register_admin_pages']);
            add_action('admin_init', [$this->library, 'maybe_seed_samples']);
            
            // AJAX handlers
            add_action('wp_ajax_cf_upload_html_template', [$this, 'ajax_upload_template']);
            add_action('wp_ajax_cf_detect_template_images', [$this, 'ajax_detect_images']);
            add_action('wp_ajax_cf_save_image_mappings', [$this, 'ajax_save_mappings']);
            add_action('wp_ajax_cf_preview_template', [$this, 'ajax_preview_template']);
            add_action('wp_ajax_cf_export_template', [$this, 'ajax_export_template']);
            add_action('wp_ajax_cf_seed_html_templates', [$this->library, 'ajax_seed_templates']);
        }
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);

        // Seed bundled templates right after activation
        add_action('complyflow_activated', [$this->library, 'seed_samples_on_activation']);
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook.
     * @return void
     */
    public function enqueue_admin_assets(string $hook): void {
        global $post_type;
        
        // Only load on our post type pages
        if ($post_type !== self::POST_TYPE && !in_array($hook, ['post.php', 'post-new.php'])) {
            return;
        }
        
        // Enqueue WordPress media library
        wp_enqueue_media();
        
        // Enqueue our scripts
        wp_enqueue_script(
            'cf-html-templates',
            COMPLYFLOW_URL . 'assets/src/js/admin/html-templates/template-admin.js',
            ['jquery', 'wp-util'],
            COMPLYFLOW_VERSION,
            true
        );
        
        // Enqueue styles
        wp_enqueue_style(
            'cf-html-templates',
            COMPLYFLOW_URL . 'assets/src/css/admin/html-templates/template-admin.css',
            [],
            COMPLYFLOW_VERSION
        );
        
        // Localize script
        wp_localize_script('cf-html-templates', 'cfHtmlTemplates', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('cf_html_template_nonce'),
            'postId' => get_the_ID() ?: 0,
            'strings' => [
                'uploadSuccess' => __('Template uploaded successfully!', 'complyflow'),
                'uploadError' => __('Failed to upload template.', 'complyflow'),
                'detectSuccess' => __('Images detected successfully!', 'complyflow'),
                'detectError' => __('Failed to detect images.', 'complyflow'),
                'saveSuccess' => __('Image mappings saved successfully!', 'complyflow'),
                'saveError' => __('Failed to save image mappings.', 'complyflow'),
                'selectFile' => __('Please select an HTML file first.', 'complyflow'),
                'invalidFile' => __('Please select a valid HTML file.', 'complyflow'),
                'chooseImage' => __('Choose Image', 'complyflow'),
                'useImage' => __('Use This Image', 'complyflow'),
            ]
        ]);
    }

    /**
     * Enqueue frontend assets
     *
     * @return void
     */
    public function enqueue_frontend_assets(): void {
        // Only enqueue if shortcode is present or we're on a template page
        global $post;
        
        if (!$post || (!has_shortcode($post->post_content, 'cf_template') && $post->post_type !== self::POST_TYPE)) {
            return;
        }
        
        wp_enqueue_style(
            'cf-html-templates-frontend',
            COMPLYFLOW_URL . 'assets/src/css/frontend/html-templates/template-frontend.css',
            [],
            COMPLYFLOW_VERSION
        );
    }

    /**
     * AJAX handler for uploading HTML template
     *
     * @return void
     */
    public function ajax_upload_template(): void {
        check_ajax_referer('cf_html_template_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Permission denied.', 'complyflow')]);
        }
        
        $post_id = intval($_POST['post_id'] ?? 0);
        
        if (!$post_id || get_post_type($post_id) !== self::POST_TYPE) {
            wp_send_json_error(['message' => __('Invalid template.', 'complyflow')]);
        }
        
        if (empty($_FILES['html_file'])) {
            wp_send_json_error(['message' => __('No file uploaded.', 'complyflow')]);
        }
        
        $result = $this->importer->import($_FILES['html_file']);
        
        if (empty($result['success'])) {
            $error = is_array($result) && isset($result['error']) ? $result['error'] : __('Failed to import template.', 'complyflow');
            wp_send_json_error(['message' => $error]);
        }

        $html_content = $result['html'] ?? '';
        $file_name = $result['filename'] ?? ($_FILES['html_file']['name'] ?? 'template.html');

        update_post_meta($post_id, '_cf_html_content', $html_content);
        update_post_meta($post_id, '_cf_html_file_name', $file_name);
        update_post_meta($post_id, '_cf_template_origin', 'upload');
        update_post_meta($post_id, '_cf_template_slug', get_post_meta($post_id, '_cf_template_slug', true) ?: sanitize_title(pathinfo($file_name, PATHINFO_FILENAME)) . '-' . $post_id);
        update_post_meta($post_id, '_cf_image_mappings', []);
        update_post_meta($post_id, '_cf_html_filesize', absint($result['size'] ?? 0));
        update_post_meta($post_id, '_cf_html_uploaded_at', current_time('mysql'));
        
        wp_send_json_success([
            'message' => __('Template uploaded successfully!', 'complyflow'),
            'html_content' => $html_content,
            'file_name' => $file_name
        ]);
    }

    /**
     * AJAX handler for detecting images in template
     *
     * @return void
     */
    public function ajax_detect_images(): void {
        check_ajax_referer('cf_html_template_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Permission denied.', 'complyflow')]);
        }
        
        $post_id = intval($_POST['post_id'] ?? 0);
        $html_content = wp_unslash($_POST['html_content'] ?? '');
        
        if (!$post_id || !$html_content) {
            wp_send_json_error(['message' => __('Invalid data.', 'complyflow')]);
        }
        
        $images = $this->detector->detect($html_content);
        
        wp_send_json_success([
            'images' => $images,
            'count' => count($images)
        ]);
    }

    /**
     * AJAX handler for saving image mappings
     *
     * @return void
     */
    public function ajax_save_mappings(): void {
        check_ajax_referer('cf_html_template_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Permission denied.', 'complyflow')]);
        }
        
        $post_id = intval($_POST['post_id'] ?? 0);
        $mappings = json_decode(wp_unslash($_POST['mappings'] ?? '[]'), true);
        
        if (!$post_id || !is_array($mappings)) {
            wp_send_json_error(['message' => __('Invalid data.', 'complyflow')]);
        }
        
        // Sanitize mappings
        $sanitized_mappings = [];
        foreach ($mappings as $mapping) {
            if (isset($mapping['id'], $mapping['url'])) {
                $sanitized_mappings[] = [
                    'id' => sanitize_text_field($mapping['id']),
                    'selector' => sanitize_text_field($mapping['selector'] ?? ''),
                    'type' => sanitize_text_field($mapping['type'] ?? 'img_tag'),
                    'url' => esc_url_raw($mapping['url']),
                    'alt' => sanitize_text_field($mapping['alt'] ?? ''),
                ];
            }
        }
        
        update_post_meta($post_id, '_cf_image_mappings', $sanitized_mappings);
        
        wp_send_json_success([
            'message' => __('Image mappings saved successfully!', 'complyflow'),
            'mappings' => $sanitized_mappings
        ]);
    }

    /**
     * AJAX handler for previewing template
     *
     * @return void
     */
    public function ajax_preview_template(): void {
        check_ajax_referer('cf_html_template_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(['message' => __('Permission denied.', 'complyflow')]);
        }
        
        $post_id = intval($_POST['post_id'] ?? 0);
        
        if (!$post_id) {
            wp_send_json_error(['message' => __('Invalid template.', 'complyflow')]);
        }
        
        $html = $this->renderer->render($post_id);
        
        if (is_wp_error($html)) {
            wp_send_json_error(['message' => $html->get_error_message()]);
        }
        
        wp_send_json_success([
            'html' => $html
        ]);
    }

    /**
     * AJAX handler for exporting template
     *
     * @return void
     */
    public function ajax_export_template(): void {
        check_ajax_referer('cf_html_template_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Permission denied.', 'complyflow'));
        }
        
        $post_id = intval($_GET['post_id'] ?? 0);
        
        if (!$post_id) {
            wp_die(__('Invalid template.', 'complyflow'));
        }
        
        $html = $this->renderer->render($post_id);
        
        if (is_wp_error($html)) {
            wp_die($html->get_error_message());
        }
        
        $post = get_post($post_id);
        $filename = sanitize_file_name($post->post_title ?: 'template') . '.html';
        
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        echo $html;
        exit;
    }

    /**
     * Get module instance
     *
     * @return HTMLTemplateModule
     */
    public static function instance(): HTMLTemplateModule {
        static $instance = null;
        
        if (null === $instance) {
            $instance = new self();
        }
        
        return $instance;
    }
}
