<?php
/**
 * Shortcode Handler
 *
 * Handles the [cf_template] shortcode for displaying HTML templates.
 *
 * @package ComplyFlow\Modules\HTMLTemplates
 * @since 5.2.0
 */

namespace ComplyFlow\Modules\HTMLTemplates;

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shortcode Handler Class
 *
 * @since 5.2.0
 */
class ShortcodeHandler {
    /**
     * Template renderer instance
     *
     * @var TemplateRenderer
     */
    private TemplateRenderer $renderer;

    /**
     * Constructor
     *
     * @param TemplateRenderer $renderer Template renderer instance.
     */
    public function __construct(TemplateRenderer $renderer) {
        $this->renderer = $renderer;
    }

    /**
     * Initialize shortcode
     *
     * @return void
     */
    public function init(): void {
        add_shortcode('cf_template', [$this, 'render_shortcode']);
    }

    /**
     * Render shortcode
     *
     * Usage:
     * [cf_template id="123"]
     * [cf_template id="123" wrap="true" container_class="my-template"]
     *
     * @param array $atts Shortcode attributes.
     * @return string Rendered template HTML.
     */
    public function render_shortcode(array $atts): string {
        $atts = shortcode_atts([
            'id' => 0,
            'wrap' => 'true',
            'container_class' => 'cf-html-template',
        ], $atts, 'cf_template');

        // Validate ID
        $post_id = absint($atts['id']);
        if ($post_id === 0) {
            return $this->render_error(__('Template ID is required.', 'complyflow'));
        }

        // Check if template exists
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'cf_html_template') {
            return $this->render_error(__('Template not found.', 'complyflow'));
        }

        // Check if template is published
        if ($post->post_status !== 'publish' && !current_user_can('edit_post', $post_id)) {
            return $this->render_error(__('Template is not available.', 'complyflow'));
        }

        // Prepare rendering arguments
        $render_args = [
            'wrap' => filter_var($atts['wrap'], FILTER_VALIDATE_BOOLEAN),
            'container_class' => sanitize_html_class($atts['container_class']),
        ];

        // Render template
        $html = $this->renderer->render($post_id, $render_args);

        if (empty($html)) {
            return $this->render_error(__('Template content is empty.', 'complyflow'));
        }

        return $html;
    }

    /**
     * Render error message
     *
     * @param string $message Error message.
     * @return string Error HTML.
     */
    private function render_error(string $message): string {
        // Only show detailed errors to admins
        if (!current_user_can('manage_options')) {
            return '<!-- ComplyFlow Template Error -->';
        }

        return sprintf(
            '<div class="cf-template-error" style="padding: 15px; background: #fee; border: 1px solid #c33; border-radius: 4px; color: #c33;">
                <strong>%s:</strong> %s
            </div>',
            esc_html__('Template Error', 'complyflow'),
            esc_html($message)
        );
    }
}
