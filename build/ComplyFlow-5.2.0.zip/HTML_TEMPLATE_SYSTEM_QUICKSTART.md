# HTML Template System - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Prerequisites
- ComplyFlow v5.2.0 or higher
- WordPress 6.4+
- PHP 8.0+

### Step 1: Enable the Module
The HTML Templates module is enabled by default. Access it via:
```
WordPress Admin > ComplyFlow > HTML Templates
```

---

## 📝 Create Your First Template

### Option A: Using the Admin Interface

1. **Navigate to Templates**
   ```
   ComplyFlow > HTML Templates > Add New
   ```

2. **Enter Template Title**
   ```
   Example: "Landing Page 2024"
   ```

3. **Upload HTML File**
   - Click "Choose File" in Upload meta box
   - Select your HTML file (max 5MB)
   - Click "Upload Template"
   - ✅ Success message appears

4. **Detect Images**
   - Click "Detect Images" button
   - System automatically finds placeholder images
   - Results appear in Images meta box

5. **Map Images**
   - For each detected image:
     - Click "Select Image" → Choose from Media Library
     - OR paste direct URL in text field
   - Click "Save Image Mappings"

6. **Preview**
   - Click "Preview Template"
   - Verify images loaded correctly

7. **Use Template**
   - Copy shortcode from Shortcode meta box
   - Paste in any page/post: `[cf_template id="123"]`

---

## 🎯 Usage Examples

### In Posts/Pages (Block Editor)
1. Add "Shortcode" block
2. Paste: `[cf_template id="123"]`
3. Publish

### In PHP Templates
```php
<?php echo do_shortcode('[cf_template id="123"]'); ?>
```

### With Custom Container Class
```
[cf_template id="123" container_class="my-landing-page"]
```

### Without Wrapper
```
[cf_template id="123" wrap="false"]
```

---

## 🔍 Supported Image Patterns

The system automatically detects:

### 1. IMG Tags
```html
<img src="https://via.placeholder.com/600x400">
<img src="https://placehold.it/300x200">
<img src="https://picsum.photos/800/600">
```

### 2. Background Images
```html
<div style="background-image: url('https://placeholder.com/800x600')"></div>
```

### 3. Data Attributes
```html
<img data-src="https://via.placeholder.com/400x300">
<div data-bg="https://placehold.it/1200x800"></div>
```

### 4. Picture Elements
```html
<picture>
    <source srcset="https://picsum.photos/800/600">
    <img src="fallback.jpg">
</picture>
```

---

## 💡 Tips & Best Practices

### ✅ DO:
- Use descriptive template titles
- Save image mappings frequently
- Preview before publishing
- Test shortcodes on staging first
- Keep HTML files under 5MB
- Use high-quality images from Media Library

### ❌ DON'T:
- Upload files with PHP code
- Use external hotlinked images (may break)
- Forget to map all detected images
- Hard-code absolute URLs in HTML

---

## 🛠️ Common Workflows

### Workflow: Import Landing Page
```
1. Export HTML from design tool (Figma, Adobe XD, etc.)
2. Upload to ComplyFlow
3. Detect placeholder images
4. Upload your brand images to Media Library
5. Map each placeholder to real image
6. Preview and verify
7. Copy shortcode to landing page
```

### Workflow: Update Existing Template
```
1. Navigate to template edit screen
2. Click "Upload Template" to replace HTML
3. Re-detect images (if structure changed)
4. Update image mappings if needed
5. Preview to verify changes
```

### Workflow: Duplicate Template
```
1. View template
2. Click "Export Template"
3. Download HTML file
4. Create new template
5. Upload downloaded file
6. Re-map images (or keep same)
```

---

## 🔒 Security Features

### Automatic Protection Against:
- ✅ PHP code injection
- ✅ Malicious JavaScript (eval, document.write)
- ✅ XSS attacks
- ✅ File size attacks (5MB limit)
- ✅ Invalid file types
- ✅ Unauthorized access

All uploads are:
- Validated for file type
- Scanned for dangerous content
- Sanitized before storage
- Nonce-protected (AJAX)
- Capability-checked

---

## 📊 Template Statistics

After uploading and detecting images, view stats:

| Metric | Description |
|--------|-------------|
| **Total Images** | Number of placeholders detected |
| **Mapped** | Images with URLs assigned |
| **Unmapped** | Images still needing assignment |
| **Completion** | Percentage of mapped images |

**Tip:** Aim for 100% completion before publishing!

---

## 🎨 Customization

### Custom CSS
Add to your theme's style.css:

```css
/* Template container */
.cf-html-template {
    margin: 40px 0;
}

/* Custom wrapper */
.my-landing-page {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}
```

### Custom JavaScript
```javascript
jQuery(document).ready(function($) {
    $('.cf-html-template').each(function() {
        console.log('Template loaded:', $(this).data('template-id'));
    });
});
```

---

## 🐛 Troubleshooting

### Problem: Upload fails
**Solution:**
```
1. Check file size < 5MB
2. Verify file extension is .html or .htm
3. Remove any PHP tags from HTML
4. Check server error logs
```

### Problem: Images not detected
**Solution:**
```
1. Ensure images use standard HTML syntax
2. Check if placeholder URLs match supported patterns
3. Try manual URL input if detection fails
```

### Problem: Shortcode shows nothing
**Solution:**
```
1. Verify template is published
2. Check template ID is correct
3. Ensure HTML content was uploaded
4. Check for JavaScript console errors
```

### Problem: Preview shows broken images
**Solution:**
```
1. Verify image URLs are accessible
2. Check HTTPS vs HTTP protocol
3. Test image URLs in browser
4. Re-upload images to Media Library
```

---

## 📖 Advanced Usage

### Programmatic Template Creation

```php
// Create template
$post_id = wp_insert_post([
    'post_title' => 'API Template',
    'post_type' => 'cf_html_template',
    'post_status' => 'publish'
]);

// Store HTML
$html = file_get_contents('path/to/template.html');
update_post_meta($post_id, '_cf_html_content', $html);

// Detect images
$detector = new \ComplyFlow\Modules\HTMLTemplates\ImageDetector();
$images = $detector->detect($html);
update_post_meta($post_id, '_cf_image_mappings', $images);

// Render
$renderer = new \ComplyFlow\Modules\HTMLTemplates\TemplateRenderer();
echo $renderer->render($post_id);
```

### Custom Filters

```php
// Modify max file size
add_filter('complyflow_html_template_max_file_size', function($size) {
    return 10485760; // 10MB
});

// Add custom placeholder pattern
add_filter('complyflow_html_template_placeholder_patterns', function($patterns) {
    $patterns[] = 'mycdn.com/placeholder';
    return $patterns;
});

// Inject custom code
add_filter('complyflow_html_template_render', function($html, $post_id) {
    // Add tracking script
    $html .= '<script>trackTemplateView(' . $post_id . ');</script>';
    return $html;
}, 10, 2);
```

---

## 📞 Getting Help

### Resources
- **Full Documentation:** `HTML_TEMPLATE_SYSTEM_DOCUMENTATION.md`
- **Plugin Settings:** `ComplyFlow > Settings`
- **Support:** Contact ShahiSoft Team

### Common Questions

**Q: Can I import from URL?**
A: Yes! Use the `TemplateImporter::import_from_url($url)` method programmatically.

**Q: What's the maximum file size?**
A: Default is 5MB. Increase via PHP settings or filter hook.

**Q: Can I use external images?**
A: Yes, but Media Library is recommended for reliability.

**Q: How many templates can I create?**
A: Unlimited! Limited only by server resources.

**Q: Can I export templates?**
A: Yes! Click "Export Template" to download HTML with replaced images.

---

## ✅ Quick Checklist

Before publishing your template:

- [ ] HTML file uploaded successfully
- [ ] All images detected
- [ ] All images mapped (100% completion)
- [ ] Preview looks correct
- [ ] Template published (not draft)
- [ ] Shortcode copied
- [ ] Tested on actual page
- [ ] Verified on mobile devices
- [ ] No console errors
- [ ] Images load quickly

---

## 🎓 Video Tutorials (Coming Soon)

1. **Basic Import** (3 min) - Upload and map your first template
2. **Advanced Techniques** (5 min) - Custom CSS, filters, and hooks
3. **Troubleshooting** (4 min) - Common issues and solutions

---

## 🚀 What's Next?

After mastering the basics:

1. **Explore Advanced Features**
   - Custom post type integration
   - REST API access (coming soon)
   - Bulk import (coming soon)

2. **Optimize Performance**
   - Cache rendered templates
   - Use CDN for images
   - Implement lazy loading

3. **Scale Your Usage**
   - Create template library
   - Build reusable components
   - Automate with WP-CLI (coming soon)

---

## 📝 Summary

The HTML Template System provides:
- ✅ Easy HTML file imports
- ✅ Automatic image detection
- ✅ WordPress Media Library integration
- ✅ Secure and validated uploads
- ✅ Simple shortcode rendering
- ✅ Export functionality
- ✅ Professional admin UI

**Ready to get started?**  
Head to: `ComplyFlow > HTML Templates > Add New`

---

**Version:** 1.0.0  
**Last Updated:** 2024-01-15  
**Module:** HTML Templates  
**Plugin:** ComplyFlow v5.2.0
